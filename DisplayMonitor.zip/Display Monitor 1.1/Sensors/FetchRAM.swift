import Combine


class MemorySensor: UsageSensor {
    override var sensorKind: SensorKind {
        return .memory
    }
    
    override var displayValue: String {
        return String(format: "%.2f MB", value)
    }
    
    override init(name: String, value: Double) {
        super.init(name: name, value: value)
    }
}

