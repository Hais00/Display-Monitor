// Sensors.h

#ifndef Sensors_h
#define Sensors_h

#include <IOKit/hid/IOHIDLib.h>
#include <Foundation/Foundation.h>
#include <CoreFoundation/CoreFoundation.h>

// Definizione della struttura SensorData per essere utilizzabile in Swift
typedef struct {
    double temperature;
    double current;
    double voltage;
} SensorData;

// Dichiarazione delle funzioni specifiche per ottenere i nomi dei sensori
CFArrayRef c_getTemperatureSensorNames(CFDictionaryRef sensors);
CFArrayRef c_getVoltageSensorNames(CFDictionaryRef sensors);
CFArrayRef c_getCurrentSensorNames(CFDictionaryRef sensors);

// Dichiarazione delle funzioni per ottenere i valori dei sensori
CFArrayRef c_getTemperatureValues(void);
CFArrayRef c_getCurrentValues(void);
CFArrayRef c_getVoltageValues(void);

// Dichiarazioni aggiuntive
CFDictionaryRef matching(int page, int usage); // Funzione matching
int getCurrentFPS(void);
void setup(void);          // Inizializza l'hook su glSwapBuffers

#endif /* Sensors_h */
