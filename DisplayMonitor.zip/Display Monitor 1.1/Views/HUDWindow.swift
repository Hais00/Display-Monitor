// HUDWindow.swift

import Cocoa
import SwiftUI
import Combine

class HUDWindow: NSPanel {
    private var overlaySettings: OverlaySettings
    private static var hudWindows = [HUDWindow]()
    
    var hostingController: NSHostingController<AnyView>?
    
    // Metodo statico per creare le finestre HUD su tutti gli schermi
    static func createHUDWindows(overlaySettings: OverlaySettings) {
        guard overlaySettings.isOverlayActive else { return }
        
        for screen in NSScreen.screens {
            let hudWindow = HUDWindow(overlaySettings: overlaySettings, hudScreen: screen)
            hudWindows.append(hudWindow)
            
            // Assicurati che la finestra sia inizializzata con le dimensioni corrette
            hudWindow.updateContentSize()
            
            hudWindow.orderFront(nil)
        }
    }
    
    private let hudScreen: NSScreen
    private var cancellables = Set<AnyCancellable>()
    
    private init(overlaySettings: OverlaySettings, hudScreen: NSScreen) {
        self.overlaySettings = overlaySettings
        self.hudScreen = hudScreen

        let panelStyle: NSWindow.StyleMask = [
            .borderless,
            .fullSizeContentView,
            .nonactivatingPanel,
            .resizable // Assicurati che .resizable sia incluso
        ]

        super.init(contentRect: hudScreen.frame,
                   styleMask: panelStyle,
                   backing: .buffered,
                   defer: false)

        // Configurazione della finestra HUD
        self.level = .floating
        self.isOpaque = false
        self.backgroundColor = NSColor.clear
        self.ignoresMouseEvents = true
        self.collectionBehavior = [
            .canJoinAllSpaces,
            .fullScreenAuxiliary,
            .stationary,
            .ignoresCycle
        ]
        self.hasShadow = false
        self.isMovableByWindowBackground = false
        self.hidesOnDeactivate = false
        self.titleVisibility = .hidden
        self.titlebarAppearsTransparent = true

        // Crea e assegna l'NSHostingController con EnvironmentObject
        let overlayView = OverlayView()
            .environmentObject(overlaySettings)
        let hostingController = NSHostingController(rootView: AnyView(overlayView))
        self.hostingController = hostingController
        self.contentView = hostingController.view

        // Imposta l'autoresizing mask
        hostingController.view.autoresizingMask = [.width, .height]

        // Applica la scala iniziale
        hostingController.view.setFrameSize(NSSize(width: hostingController.view.fittingSize.width * overlaySettings.overlayScale,
                                                  height: hostingController.view.fittingSize.height * overlaySettings.overlayScale))

        self.setContentSize(NSSize(width: hostingController.view.frame.width,
                                   height: hostingController.view.frame.height))
        self.contentView?.layoutSubtreeIfNeeded()

        // Aggiungi gli osservatori
        setupObservers()

        // Posiziona inizialmente la finestra
        self.updatePosition()
    }

    private func sizeToFitContent() {
        guard let contentView = self.contentView else { return }
        let baseSize = contentView.fittingSize
        let scale = overlaySettings.overlayScale
        let scaledSize = CGSize(width: baseSize.width * scale, height: baseSize.height * scale)

        // Aggiorna la dimensione della finestra
        self.setContentSize(scaledSize)
        self.contentView?.layoutSubtreeIfNeeded()

        // Reimposta la posizione per tenere conto della nuova dimensione
        updatePosition()
    }


    private func setupObservers() {
        overlaySettings.$overlayScale
            .receive(on: RunLoop.main)
            .sink { [weak self] _ in
                self?.sizeToFitContent()
            }
            .store(in: &cancellables)

        overlaySettings.$customCategories
            .receive(on: RunLoop.main)
            .sink { [weak self] _ in
                self?.sizeToFitContent()
            }
            .store(in: &cancellables)

        // Osserva altre proprietà se necessario
    }


    
    private func updateContentSize() {
        guard let hostingController = self.hostingController else { return }
        let baseSize = hostingController.view.fittingSize
        let scaledSize = CGSize(width: baseSize.width, height: baseSize.height)
        
        NSAnimationContext.runAnimationGroup { context in
            context.duration = 0.2
            self.animator().setContentSize(scaledSize)
        }

        self.contentView?.invalidateIntrinsicContentSize()
        self.contentView?.needsLayout = true
        self.contentView?.layoutSubtreeIfNeeded()

        // Recalculate the position
        updatePosition()
    }




    
    private func calculatePosition(for screen: NSScreen, position: OverlayPosition) -> NSPoint {
        let screenFrame = screen.frame
        let overlaySize = self.frame.size

        // Debug prints
        print("Screen Frame for \(position.description): \(screenFrame)")
        print("Overlay Size: \(overlaySize)")

        var x: CGFloat = 0
        var y: CGFloat = 0

        let padding: CGFloat = 20.0 // Padding da applicare rispetto ai bordi dello schermo

        switch position {
        case .topLeft:
            x = screenFrame.minX + padding
            y = screenFrame.maxY - padding
        case .topCenter:
            x = screenFrame.midX - overlaySize.width / 2
            y = screenFrame.maxY - padding
        case .topRight:
            x = screenFrame.maxX - overlaySize.width - padding
            y = screenFrame.maxY - padding
        case .centerRight:
            x = screenFrame.maxX - overlaySize.width - padding
            y = screenFrame.midY + (overlaySize.height / 2)
        case .bottomRight:
            x = screenFrame.maxX - overlaySize.width - padding
            y = screenFrame.minY + padding + overlaySize.height // Modificato
        case .bottomCenter:
            x = screenFrame.midX - overlaySize.width / 2
            y = screenFrame.minY + padding + overlaySize.height // Modificato
        case .bottomLeft:
            x = screenFrame.minX + padding
            y = screenFrame.minY + padding + overlaySize.height // Modificato
        case .centerLeft:
            x = screenFrame.minX + padding
            y = screenFrame.midY + (overlaySize.height / 2)
        }

        print("Calculated Position for \(position.description): (x: \(x), y: \(y))")

        return NSPoint(x: x, y: y)
    }

    private func updatePosition() {
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            let positionPoint = self.calculatePosition(for: self.hudScreen, position: self.overlaySettings.overlayPosition)
            self.setFrameTopLeftPoint(positionPoint)
        }
    }
    
    static func closeAllHUDWindows() {
        hudWindows.forEach { $0.close() }
        hudWindows.removeAll()
    }
}
