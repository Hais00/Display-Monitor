//
//  smc.swift
//  SMC
//
//  Created by Serhiy Mytrovtsiy on 25/05/2021.
//  Modified by [Your Name] on [Today's Date].
//  Using Swift 5.0.
//  Running on macOS 10.15.
//
//  Copyright © 2021 Serhiy Mytrovtsiy. All rights reserved.
//

import Foundation
import IOKit
import Combine

// MARK: - SMC Data Types and Keys
internal enum SMCDataType: String {
    case UI8 = "ui8 "
    case UI16 = "ui16"
    case UI32 = "ui32"
    case SP1E = "sp1e"
    case SP3C = "sp3c"
    case SP4B = "sp4b" // Corrected from sp5b to sp4b
    case SP5A = "sp5a"
    case SPA5 = "spa5"
    case SP69 = "sp69" // Corrected from sp669 to sp69
    case SP78 = "sp78"
    case SP87 = "sp87"
    case SP96 = "sp96"
    case SPB4 = "spb4"
    case SPF0 = "spf0"
    case FLT = "flt "
    case FPE2 = "fpe2"
    case FP2E = "fp2e"
    case FDS = "{fds"
}

internal enum SMCKeys: UInt8 {
    case kernelIndex = 2
    case readBytes = 5
    case writeBytes = 6
    case readIndex = 8
    case readKeyInfo = 9
    case readPLimit = 11
    case readVers = 12
}

public enum FanMode: Int, Codable {
    case automatic = 0
    case forced = 1
}

// MARK: - SMC Data Structures

internal struct SMCKeyData_t {
    typealias SMCBytes_t = (UInt8, UInt8, UInt8, UInt8, UInt8, UInt8, UInt8,
                            UInt8, UInt8, UInt8, UInt8, UInt8, UInt8, UInt8,
                            UInt8, UInt8, UInt8, UInt8, UInt8, UInt8, UInt8,
                            UInt8, UInt8, UInt8, UInt8, UInt8, UInt8, UInt8,
                            UInt8, UInt8, UInt8, UInt8)

    struct vers_t {
        var major: CUnsignedChar = 0
        var minor: CUnsignedChar = 0
        var build: CUnsignedChar = 0
        var reserved: CUnsignedChar = 0
        var release: CUnsignedShort = 0
    }

    struct LimitData_t {
        var version: UInt16 = 0
        var length: UInt16 = 0
        var cpuPLimit: UInt32 = 0
        var gpuPLimit: UInt32 = 0
        var memPLimit: UInt32 = 0
    }

    struct keyInfo_t {
        var dataSize: IOByteCount32 = 0
        var dataType: UInt32 = 0
        var dataAttributes: UInt8 = 0
    }

    var key: UInt32 = 0
    var vers = vers_t()
    var pLimitData = LimitData_t()
    var keyInfo = keyInfo_t()
    var padding: UInt16 = 0
    var result: UInt8 = 0
    var status: UInt8 = 0
    var data8: UInt8 = 0
    var data32: UInt32 = 0
    var bytes: SMCBytes_t = (UInt8(0), UInt8(0), UInt8(0), UInt8(0), UInt8(0), UInt8(0),
                             UInt8(0), UInt8(0), UInt8(0), UInt8(0), UInt8(0), UInt8(0),
                             UInt8(0), UInt8(0), UInt8(0), UInt8(0), UInt8(0), UInt8(0),
                             UInt8(0), UInt8(0), UInt8(0), UInt8(0), UInt8(0), UInt8(0),
                             UInt8(0), UInt8(0), UInt8(0), UInt8(0), UInt8(0), UInt8(0),
                             UInt8(0), UInt8(0))
}

internal struct SMCVal_t {
    var key: String
    var dataSize: UInt32 = 0
    var dataType: String = ""
    var bytes: [UInt8] = Array(repeating: 0, count: 32)

    init(_ key: String) {
        self.key = key
    }
}

// MARK: - Extensions

extension FourCharCode {
    init(fromString str: String) {
        precondition(str.count == 4)

        self = str.utf8.reduce(0) { sum, character in
            return sum << 8 | UInt32(character)
        }
    }

    func toString() -> String {
        var str = ""
        for i in stride(from: 24, to: -8, by: -8) {
            if let scalar = UnicodeScalar((self >> i) & 0xFF) {
                str += String(scalar)
            } else {
                str += "?"
            }
        }
        return str
    }
}

extension UInt16 {
    init(bytes: (UInt8, UInt8)) {
        self = UInt16(bytes.0) << 8 | UInt16(bytes.1)
    }
}

extension UInt32 {
    init(bytes: (UInt8, UInt8, UInt8, UInt8)) {
        self = UInt32(bytes.0) << 24 | UInt32(bytes.1) << 16 | UInt32(bytes.2) << 8 | UInt32(bytes.3)
    }
}

extension Int {
    init(fromFPE2 bytes: (UInt8, UInt8)) {
        self = (Int(bytes.0) << 6) + (Int(bytes.1) >> 2)
    }
}

extension Float {
    init?(_ bytes: [UInt8]) {
        guard bytes.count >= 4 else { return nil }
        var value: Float = 0
        withUnsafeMutableBytes(of: &value) { ptr in
            ptr.copyBytes(from: bytes[0..<4])
        }
        self = value
    }

    var bytes: [UInt8] {
        withUnsafeBytes(of: self, Array.init)
    }
}

// MARK: - Sensor Structures and Enums

public enum Group {
    case CPU
    case GPU
    case system
    case sensor
    case ANE
}

public enum SensorType: String {
    case temperature = "Temperature"
    case voltage = "Voltage"
    case current = "Current"
    case power = "Power"
    case fan = "Fan" // Added new type
    
}

public enum Platform: String {
    case intel
    case apple
    case m1
    case m2
    case m3
    case m4
    case all
}

public struct Sensor {
    let key: String
    let name: String
    let type: SensorType
    let group: Group?
    let platforms: [Platform]?
    let average: Bool?

    init(key: String, name: String, type: SensorType, group: Group? = nil, platforms: [Platform]? = nil, average: Bool? = false) {
        self.key = key
        self.name = name
        self.type = type
        self.group = group
        self.platforms = platforms
        self.average = average
    }
}

// MARK: - Unit Mapping

func unit(for type: SensorType) -> String {
    switch type {
    case .temperature:
        return "°C"
    case .voltage:
        return "V"
    case .current:
        return "A"
    case .power:
        return "W"
    case .fan:
        return "RPM" // Assuming RPM is the correct unit for fans
    }
}

// Assume HIDSensors, PowermetricsSensors, and SMCSensors are defined and configured
let hidSensors = HIDSensors()                     // Create an instance of HID sensors
let powermetricsSensors = PowermetricsSensors()   // Create an instance of Powermetrics sensors
let smcSensors = SMCSensors()                     // Create an instance of SMC sensors

// MARK: - SMC Class

public class SMC {
    weak var controller: SMCController?
    private static var _shared: SMC?
    public static var shared: SMC {
        if let instance = _shared {
            return instance
        } else {
            fatalError("SMC non è stato inizializzato. Assicurati di chiamare SMC.initialize(overlaySettings:) prima di utilizzarlo.")
        }
    }

    public static func initialize(overlaySettings: OverlaySettings) {
        _shared = SMC(overlaySettings: overlaySettings)
    }
    
    private var overlaySettings: OverlaySettings
    private var cancellables = Set<AnyCancellable>()
    private var conn: io_connect_t = 0
    private let platform: Platform
    private var sensorLookup: [String: Sensor] = [:]
    
    private var chipName: String? = SMC.getChipName()
    // Dictionary to store the current sensors being displayed
    private var currentSensors: [SensorType: [SMCSensorData]] = [
        .temperature: [],
        .current: [],
        .voltage: [],
        .power: [],
        .fan: [] // Added new type
    ]
    
    // MARK: - Fan Data Dictionary
    private var fanDataDict: [Int: (ac: Double, mn: Double, mx: Double, tg: Double)] = [:]
    
    private func observeUnknownSensorFlag() {
        overlaySettings.$showUnknownSensors
            .sink { [weak self] newValue in
                print("Debug: Cambiamento `showUnknownSensors` a \(newValue)")
                self?.updateParsedSensors()
            }
            .store(in: &cancellables)
    }

    public init(overlaySettings: OverlaySettings) {
        self.overlaySettings = overlaySettings
        self.platform = SMC.determinePlatform(from: self.chipName ?? "")
        self.observeUnknownSensorFlag()
        
        // Debug logs to confirm chipName and platform values
        print("Chip Rilevato: \(self.chipName ?? "Sconosciuto")")
        print("Piattaforma Rilevata: \(self.platform)")
        
        // Connect to the SMC IOKit service
        var result: kern_return_t
        var iterator: io_iterator_t = 0
        let device: io_object_t

        let matchingDictionary: CFMutableDictionary = IOServiceMatching("AppleSMC")
        result = IOServiceGetMatchingServices(kIOMasterPortDefault, matchingDictionary, &iterator)
        if result != kIOReturnSuccess {
            print("Errore IOServiceGetMatchingServices(): " + (String(cString: mach_error_string(result), encoding: .ascii) ?? "errore sconosciuto"))
            return
        }

        device = IOIteratorNext(iterator)
        IOObjectRelease(iterator)
        if device == 0 {
            print("Errore IOIteratorNext(): " + (String(cString: mach_error_string(result), encoding: .ascii) ?? "errore sconosciuto"))
            return
        }

        result = IOServiceOpen(device, mach_task_self_, 0, &conn)
        IOObjectRelease(device)
        if result != kIOReturnSuccess {
            print("Errore IOServiceOpen(): " + (String(cString: mach_error_string(result), encoding: .ascii) ?? "errore sconosciuto"))
            return
        }
        
        // Inizializza i sensori correnti
        self.updateParsedSensors()
    }

    deinit {
        let result = self.close()
        if result != kIOReturnSuccess {
            print("Errore chiusura connessione SMC: " + (String(cString: mach_error_string(result), encoding: String.Encoding.ascii) ?? "errore sconosciuto"))
        }
    }

    public func close() -> kern_return_t {
        return IOServiceClose(conn)
    }

    // MARK: - Chip Detection Functions

    /// Recupera il nome del chip utilizzando sysctl
    private static func getChipName() -> String? {
        var size = 0
        let result = sysctlbyname("machdep.cpu.brand_string", nil, &size, nil, 0)
        if result != 0 {
            return nil
        }

        var buffer = [CChar](repeating: 0, count: size)
        let result2 = sysctlbyname("machdep.cpu.brand_string", &buffer, &size, nil, 0)
        if result2 != 0 {
            return nil
        }

        return String(cString: buffer)
    }

    /// Determina la piattaforma basandosi sul nome del chip
    private static func determinePlatform(from chipName: String) -> Platform {
        let lowercasedChipName = chipName.lowercased()
        if lowercasedChipName.contains("intel") {
            return .intel
        } else if lowercasedChipName.contains("apple m1") {
            return .m1
        } else if lowercasedChipName.contains("apple m2") {
            return .m2
        } else if lowercasedChipName.contains("apple m3") {
            return .m3
        } else if lowercasedChipName.contains("apple m4") {
            return .m4
        } else {
            return .all
        }
    }

    // MARK: - SMC Value Retrieval

    public func getValue(_ key: String) -> Double? {
        var result: kern_return_t = 0
        var val: SMCVal_t = SMCVal_t(key)

        result = read(&val)
        if result != kIOReturnSuccess {
            print("Errore lettura (\(key)): " + (String(cString: mach_error_string(result), encoding: String.Encoding.ascii) ?? "errore sconosciuto"))
            return nil
        }

        if val.dataSize > 0 {
            if val.bytes.first(where: { $0 != 0 }) == nil && val.key != "FS! " && val.key != "F0Md" && val.key != "F1Md" {
                return nil
            }

            switch val.dataType {
            case SMCDataType.UI8.rawValue:
                return Double(val.bytes[0])
            case SMCDataType.UI16.rawValue:
                return Double(UInt16(bytes: (val.bytes[0], val.bytes[1])))
            case SMCDataType.UI32.rawValue:
                return Double(UInt32(bytes: (val.bytes[0], val.bytes[1], val.bytes[2], val.bytes[3])))
            case SMCDataType.SP1E.rawValue:
                let result: Double = Double(UInt16(val.bytes[0]) * 256 + UInt16(val.bytes[1]))
                return Double(result / 16384)
            case SMCDataType.SP3C.rawValue:
                let result: Double = Double(UInt16(val.bytes[0]) * 256 + UInt16(val.bytes[1]))
                return Double(result / 4096)
            case SMCDataType.SP4B.rawValue:
                let result: Double = Double(UInt16(val.bytes[0]) * 256 + UInt16(val.bytes[1]))
                return Double(result / 2048)
            case SMCDataType.SP5A.rawValue:
                let result: Double = Double(UInt16(val.bytes[0]) * 256 + UInt16(val.bytes[1]))
                return Double(result / 1024)
            case SMCDataType.SP69.rawValue:
                let result: Double = Double(UInt16(val.bytes[0]) * 256 + UInt16(val.bytes[1]))
                return Double(result / 512)
            case SMCDataType.SP78.rawValue:
                let intValue: Double = Double(Int(val.bytes[0]) * 256 + Int(val.bytes[1]))
                return Double(intValue / 256)
            case SMCDataType.SP87.rawValue:
                let intValue: Double = Double(Int(val.bytes[0]) * 256 + Int(val.bytes[1]))
                return Double(intValue / 128)
            case SMCDataType.SP96.rawValue:
                let intValue: Double = Double(Int(val.bytes[0]) * 256 + Int(val.bytes[1]))
                return Double(intValue / 64)
            case SMCDataType.SPA5.rawValue:
                let result: Double = Double(UInt16(val.bytes[0]) * 256 + UInt16(val.bytes[1]))
                return Double(result / 32)
            case SMCDataType.SPB4.rawValue:
                let intValue: Double = Double(Int(val.bytes[0]) * 256 + Int(val.bytes[1]))
                return Double(intValue / 16)
            case SMCDataType.SPF0.rawValue:
                let intValue: Double = Double(Int(val.bytes[0]) * 256 + Int(val.bytes[1]))
                return intValue
            case SMCDataType.FLT.rawValue:
                let value: Float? = Float(val.bytes)
                if let value = value {
                    return Double(value)
                }
                return nil
            case SMCDataType.FPE2.rawValue:
                return Double(Int(fromFPE2: (val.bytes[0], val.bytes[1])))
            default:
                return nil
            }
        }

        return nil
    }

    public func getStringValue(_ key: String) -> String? {
        var result: kern_return_t = 0
        var val: SMCVal_t = SMCVal_t(key)

        result = read(&val)
        if result != kIOReturnSuccess {
            print("Errore lettura chiave (\(key)): " + (String(cString: mach_error_string(result), encoding: String.Encoding.ascii) ?? "errore sconosciuto"))
            return nil
        }

        if val.dataSize > 0 {
            if val.bytes.first(where: { $0 != 0 }) == nil {
                return nil
            }

            switch val.dataType {
            case SMCDataType.FDS.rawValue:
                // Use String(bytes:encoding:) for a simpler conversion
                let byteRange = 4..<16
                if byteRange.lowerBound >= val.bytes.count {
                    return nil
                }
                let byteSlice = val.bytes[byteRange]
                if let string = String(bytes: byteSlice, encoding: .ascii) {
                    return string.trimmingCharacters(in: .whitespaces)
                } else {
                    return nil
                }
            default:
                print("Tipo di dato non supportato \(val.dataType) per la chiave: \(key)")
                return nil
            }
        }

        return nil
    }


    public func getAllKeys() -> [String] {
        var list: [String] = []

        guard let keysNum = self.getValue("#KEY") else {
            print("ERRORE nessun conteggio delle chiavi trovato")
            return list
        }

        var result: kern_return_t = 0
        var input: SMCKeyData_t = SMCKeyData_t()
        var output: SMCKeyData_t = SMCKeyData_t()

        for i in 0..<Int(keysNum) { // Corrected the range
            input = SMCKeyData_t()
            output = SMCKeyData_t()

            input.data8 = SMCKeys.readIndex.rawValue
            input.data32 = UInt32(i)

            result = call(SMCKeys.kernelIndex.rawValue, input: &input, output: &output)
            if result != kIOReturnSuccess {
                continue
            }

            list.append(output.key.toString())
        }

        return list
    }

    public func write(_ key: String, _ newValue: Int) -> kern_return_t {
        var value = SMCVal_t(key)
        value.dataSize = 2
        value.bytes = [UInt8(newValue >> 6), UInt8((newValue << 2) ^ ((newValue >> 6) & 0xFF)), UInt8(0), UInt8(0), UInt8(0), UInt8(0),
                       UInt8(0), UInt8(0), UInt8(0), UInt8(0), UInt8(0), UInt8(0),
                       UInt8(0), UInt8(0), UInt8(0), UInt8(0), UInt8(0), UInt8(0),
                       UInt8(0), UInt8(0), UInt8(0), UInt8(0), UInt8(0), UInt8(0),
                       UInt8(0), UInt8(0), UInt8(0), UInt8(0), UInt8(0), UInt8(0),
                       UInt8(0), UInt8(0)]

        return write(value)
    }

    // MARK: - Fans Management
    public static func setFanMode(_ id: Int, mode: FanMode) {
            shared.setFanMode(id, mode: mode)
        }
    public static func setFanSpeed(_ id: Int, speed: Int) {
            shared.setFanSpeed(id, speed: speed)
        }

        public static func resetFans() {
            shared.resetFans()
        }
    public  func setFanMode(_ id: Int, mode: FanMode) {
        if self.getValue("F\(id)Md") != nil {
            var result: kern_return_t = 0
            var value = SMCVal_t("F\(id)Md")

            result = read(&value)
            if result != kIOReturnSuccess {
                print("Errore lettura modalità ventola: " + (String(cString: mach_error_string(result), encoding: String.Encoding.ascii) ?? "errore sconosciuto"))
                return
            }

            value.bytes = [UInt8(mode.rawValue), UInt8(0), UInt8(0), UInt8(0), UInt8(0), UInt8(0),
                           UInt8(0), UInt8(0), UInt8(0), UInt8(0), UInt8(0), UInt8(0),
                           UInt8(0), UInt8(0), UInt8(0), UInt8(0), UInt8(0), UInt8(0),
                           UInt8(0), UInt8(0), UInt8(0), UInt8(0), UInt8(0), UInt8(0),
                           UInt8(0), UInt8(0), UInt8(0), UInt8(0), UInt8(0), UInt8(0),
                           UInt8(0), UInt8(0)]

            result = write(value)
            if result != kIOReturnSuccess {
                print("Errore scrittura modalità ventola: " + (String(cString: mach_error_string(result), encoding: String.Encoding.ascii) ?? "errore sconosciuto"))
                return
            }
        }

        let fansMode = Int(self.getValue("FS! ") ?? 0)
        var newMode: UInt8 = 0

        if fansMode == 0 && id == 0 && mode == .forced {
            newMode = 1
        } else if fansMode == 0 && id == 1 && mode == .forced {
            newMode = 2
        } else if fansMode == 1 && id == 0 && mode == .automatic {
            newMode = 0
        } else if fansMode == 1 && id == 1 && mode == .forced {
            newMode = 3
        } else if fansMode == 2 && id == 1 && mode == .automatic {
            newMode = 0
        } else if fansMode == 2 && id == 0 && mode == .forced {
            newMode = 3
        } else if fansMode == 3 && id == 0 && mode == .automatic {
            newMode = 2
        } else if fansMode == 3 && id == 1 && mode == .automatic {
            newMode = 1
        }

        if fansMode == newMode {
            return
        }

        var result: kern_return_t = 0
        var valueFS = SMCVal_t("FS! ")

        result = read(&valueFS)
        if result != kIOReturnSuccess {
            print("Errore lettura modalità ventola: " + (String(cString: mach_error_string(result), encoding: String.Encoding.ascii) ?? "errore sconosciuto"))
            return
        }

        valueFS.bytes = [0, newMode, UInt8(0), UInt8(0), UInt8(0), UInt8(0),
                         UInt8(0), UInt8(0), UInt8(0), UInt8(0), UInt8(0), UInt8(0),
                         UInt8(0), UInt8(0), UInt8(0), UInt8(0), UInt8(0), UInt8(0),
                         UInt8(0), UInt8(0), UInt8(0), UInt8(0), UInt8(0), UInt8(0),
                         UInt8(0), UInt8(0), UInt8(0), UInt8(0), UInt8(0), UInt8(0),
                         UInt8(0), UInt8(0)]

        result = write(valueFS)
        if result != kIOReturnSuccess {
            print("Errore scrittura modalità ventola: " + (String(cString: mach_error_string(result), encoding: String.Encoding.ascii) ?? "errore sconosciuto"))
            return
        }
    }

    public func setFanSpeed(_ id: Int, speed: Int) {
        let maxSpeed = Int(self.getValue("F\(id)Mx") ?? 4000)

        if speed > maxSpeed {
            print("La nuova velocità della ventola (\(speed)) supera la velocità massima (\(maxSpeed))")
            return
        }

        var result: kern_return_t = 0
        var value = SMCVal_t("F\(id)Tg")
        result = read(&value)
        if result != kIOReturnSuccess {
            print("Errore lettura valore ventola: " + (String(cString: mach_error_string(result), encoding: String.Encoding.ascii) ?? "errore sconosciuto"))
            return
        }

        if value.dataType == "flt " {
            // Correction: Remove optional binding
            let floatValue = Float(speed)
            let bytes = floatValue.bytes
            if bytes.count >= 4 {
                value.bytes[0] = bytes[0]
                value.bytes[1] = bytes[1]
                value.bytes[2] = bytes[2]
                value.bytes[3] = bytes[3]
            }
        } else if value.dataType == "fpe2" {
            value.bytes[0] = UInt8(speed >> 6)
            value.bytes[1] = UInt8((speed << 2) ^ ((speed >> 6) & 0xFF))
            value.bytes[2] = UInt8(0)
            value.bytes[3] = UInt8(0)
        }

        result = write(value)
        if result != kIOReturnSuccess {
            print("Errore scrittura velocità ventola: " + (String(cString: mach_error_string(result), encoding: String.Encoding.ascii) ?? "errore sconosciuto"))
            return
        }
    }

    public func resetFans() {
        var value = SMCVal_t("FS! ")
        value.dataSize = 2

        let result = write(value)
        if result != kIOReturnSuccess {
            print("Errore scrittura per reset delle ventole: " + (String(cString: mach_error_string(result), encoding: String.Encoding.ascii) ?? "errore sconosciuto"))
        }
    }

    // MARK: - Internal Functions

    private func read(_ value: UnsafeMutablePointer<SMCVal_t>) -> kern_return_t {
        var result: kern_return_t = 0
        var input = SMCKeyData_t()
        var output = SMCKeyData_t()

        input.key = FourCharCode(fromString: value.pointee.key)
        input.data8 = SMCKeys.readKeyInfo.rawValue

        result = call(SMCKeys.kernelIndex.rawValue, input: &input, output: &output)
        if result != kIOReturnSuccess {
            return result
        }

        value.pointee.dataSize = UInt32(output.keyInfo.dataSize)
        value.pointee.dataType = output.keyInfo.dataType.toString()
        input.keyInfo.dataSize = output.keyInfo.dataSize
        input.data8 = SMCKeys.readBytes.rawValue

        result = call(SMCKeys.kernelIndex.rawValue, input: &input, output: &output)
        if result != kIOReturnSuccess {
            return result
        }

        // Convert the output.bytes tuple to an array
        let outputBytesArray: [UInt8] = [
            output.bytes.0, output.bytes.1, output.bytes.2, output.bytes.3,
            output.bytes.4, output.bytes.5, output.bytes.6, output.bytes.7,
            output.bytes.8, output.bytes.9, output.bytes.10, output.bytes.11,
            output.bytes.12, output.bytes.13, output.bytes.14, output.bytes.15,
            output.bytes.16, output.bytes.17, output.bytes.18, output.bytes.19,
            output.bytes.20, output.bytes.21, output.bytes.22, output.bytes.23,
            output.bytes.24, output.bytes.25, output.bytes.26, output.bytes.27,
            output.bytes.28, output.bytes.29, output.bytes.30, output.bytes.31
        ]

        // Copy the bytes into the SMCVal_t bytes array
        for i in 0..<Int(value.pointee.dataSize) {
            if i < value.pointee.bytes.count && i < outputBytesArray.count {
                value.pointee.bytes[i] = outputBytesArray[i]
            }
        }

        return kIOReturnSuccess
    }

    private func write(_ value: SMCVal_t) -> kern_return_t {
        var input = SMCKeyData_t()
        var output = SMCKeyData_t()

        input.key = FourCharCode(fromString: value.key)
        input.data8 = SMCKeys.writeBytes.rawValue
        input.keyInfo.dataSize = IOByteCount32(value.dataSize)

        // Convert the byte array to a tuple
        let bytesTuple: SMCKeyData_t.SMCBytes_t = (
            value.bytes.count > 0 ? value.bytes[0] : UInt8(0),
            value.bytes.count > 1 ? value.bytes[1] : UInt8(0),
            value.bytes.count > 2 ? value.bytes[2] : UInt8(0),
            value.bytes.count > 3 ? value.bytes[3] : UInt8(0),
            value.bytes.count > 4 ? value.bytes[4] : UInt8(0),
            value.bytes.count > 5 ? value.bytes[5] : UInt8(0),
            value.bytes.count > 6 ? value.bytes[6] : UInt8(0),
            value.bytes.count > 7 ? value.bytes[7] : UInt8(0),
            value.bytes.count > 8 ? value.bytes[8] : UInt8(0),
            value.bytes.count > 9 ? value.bytes[9] : UInt8(0),
            value.bytes.count > 10 ? value.bytes[10] : UInt8(0),
            value.bytes.count > 11 ? value.bytes[11] : UInt8(0),
            value.bytes.count > 12 ? value.bytes[12] : UInt8(0),
            value.bytes.count > 13 ? value.bytes[13] : UInt8(0),
            value.bytes.count > 14 ? value.bytes[14] : UInt8(0),
            value.bytes.count > 15 ? value.bytes[15] : UInt8(0),
            value.bytes.count > 16 ? value.bytes[16] : UInt8(0),
            value.bytes.count > 17 ? value.bytes[17] : UInt8(0),
            value.bytes.count > 18 ? value.bytes[18] : UInt8(0),
            value.bytes.count > 19 ? value.bytes[19] : UInt8(0),
            value.bytes.count > 20 ? value.bytes[20] : UInt8(0),
            value.bytes.count > 21 ? value.bytes[21] : UInt8(0),
            value.bytes.count > 22 ? value.bytes[22] : UInt8(0),
            value.bytes.count > 23 ? value.bytes[23] : UInt8(0),
            value.bytes.count > 24 ? value.bytes[24] : UInt8(0),
            value.bytes.count > 25 ? value.bytes[25] : UInt8(0),
            value.bytes.count > 26 ? value.bytes[26] : UInt8(0),
            value.bytes.count > 27 ? value.bytes[27] : UInt8(0),
            value.bytes.count > 28 ? value.bytes[28] : UInt8(0),
            value.bytes.count > 29 ? value.bytes[29] : UInt8(0),
            value.bytes.count > 30 ? value.bytes[30] : UInt8(0),
            value.bytes.count > 31 ? value.bytes[31] : UInt8(0)
        )

        input.bytes = bytesTuple

        let result = self.call(SMCKeys.kernelIndex.rawValue, input: &input, output: &output)
        if result != kIOReturnSuccess {
            return result
        }

        return kIOReturnSuccess
    }

    private func call(_ index: UInt8, input: inout SMCKeyData_t, output: inout SMCKeyData_t) -> kern_return_t {
        let inputSize = MemoryLayout<SMCKeyData_t>.stride
        var outputSize = MemoryLayout<SMCKeyData_t>.stride

        return IOConnectCallStructMethod(conn, UInt32(index), &input, inputSize, &output, &outputSize)
    }

    // MARK: - New Function to Get Parsed Sensors

    public struct SMCSensorData {
        public let name: String
        public var value: Double?
        public let unit: String
        public let origin: String
    }

    /// Aggiorna i valori dei sensori esistenti senza ricreare l'intero dizionario
    public func updateParsedSensors() {
        print("Debug: Chiamata a updateParsedSensors(), flag showUnknownSensors = \(overlaySettings.showUnknownSensors)")
        
        // Recupera tutti i dati dei sensori
        let allSensorData = fetchAllSensorData()
        
        // Itera attraverso ciascun tipo di sensore
        for (type, sensorDataList) in allSensorData {
            // Se il tipo di sensore esiste già in currentSensors, aggiorna i valori
            if var existingSensors = currentSensors[type] {
                for newSensorData in sensorDataList {
                    if let index = existingSensors.firstIndex(where: { $0.name == newSensorData.name && $0.origin == newSensorData.origin }) {
                        existingSensors[index].value = newSensorData.value
                    } else {
                        existingSensors.append(newSensorData)
                    }
                }
                currentSensors[type] = existingSensors
            } else {
                // Aggiungi nuovi tipi di sensori se non esistono
                currentSensors[type] = sensorDataList
            }
        }
        
        // Gestione delle ventole
        updateFanData()
        for (fanNumber, fanValues) in fanDataDict {
            let fanName = "Fan \(fanNumber)"
            let fanAcData = SMCSensorData(name: "\(fanName) - Current Speed", value: fanValues.ac, unit: "RPM", origin: "SMC")
            let fanMnData = SMCSensorData(name: "\(fanName) - Min Value", value: fanValues.mn, unit: "RPM", origin: "SMC")
            let fanMxData = SMCSensorData(name: "\(fanName) - Max Value", value: fanValues.mx, unit: "RPM", origin: "SMC")
            let fanTgData = SMCSensorData(name: "\(fanName) - Target Value", value: fanValues.tg, unit: "RPM", origin: "SMC")
            
            if var fanSensors = currentSensors[.fan] {
                if let index = fanSensors.firstIndex(where: { $0.name == "\(fanName) - Current Speed" }) {
                    fanSensors[index].value = fanAcData.value
                } else {
                    fanSensors.append(fanAcData)
                }
                
                if let index = fanSensors.firstIndex(where: { $0.name == "\(fanName) - Min Value" }) {
                    fanSensors[index].value = fanMnData.value
                } else {
                    fanSensors.append(fanMnData)
                }
                
                if let index = fanSensors.firstIndex(where: { $0.name == "\(fanName) - Max Value" }) {
                    fanSensors[index].value = fanMxData.value
                } else {
                    fanSensors.append(fanMxData)
                }
                
                if let index = fanSensors.firstIndex(where: { $0.name == "\(fanName) - Target Value" }) {
                    fanSensors[index].value = fanTgData.value
                } else {
                    fanSensors.append(fanTgData)
                }
                
                currentSensors[.fan] = fanSensors
            } else {
                currentSensors[.fan] = [fanAcData, fanMnData, fanMxData, fanTgData]
            }
        }
        
        // Calcola le medie dopo aver aggiornato i sensori
        computeAverages()
        
        // Notifica al controller che i sensori sono stati aggiornati
        controller?.updateSMCSensors()
    }

    
    /// Recupera tutti i dati dei sensori categorizzati
    private func fetchAllSensorData() -> [SensorType: [SMCSensorData]] {
        var categorizedSensors: [SensorType: [SMCSensorData]] = [
            .temperature: [],
            .current: [],
            .voltage: [],
            .power: [],
            .fan: []
        ]

        // Reset del sensorLookup
        sensorLookup = [:]
        var sensorLookupTemp: [String: Sensor] = [:]

        for (_, sensors) in SensorsList {
            for sensor in sensors {
                if sensor.platforms?.contains(self.platform) ?? true {
                    sensorLookupTemp[sensor.key] = sensor
                }
            }
        }
        sensorLookup = sensorLookupTemp

        let allKeys = self.getAllKeys()

        // Definizione dei prefissi validi (sia maiuscoli che minuscoli)
        let validPrefixes: [Character: (unit: String, type: SensorType)] = [
            "T": ("°C", .temperature),
            "t": ("°C", .temperature),
            "I": ("A", .current),
            "i": ("A", .current),
            "V": ("V", .voltage),
            "v": ("V", .voltage),
            "P": ("W", .power),
            "p": ("W", .power),
            "F": ("RPM", .fan),
            "f": ("RPM", .fan)
        ]

        for key in allKeys {
            guard let firstChar = key.first else {
                continue // Ignora le chiavi vuote
            }

            guard let sensorInfo = validPrefixes[firstChar] else {
                // Ignora altamente i sensori con prefissi non validi
                continue
            }

            let unit = sensorInfo.unit
            let sensorType = sensorInfo.type

            if let sensor = sensorLookup[key] {
                if let value = self.getValue(key) {
                    let sensorData = SMCSensorData(name: sensor.name, value: value, unit: unit, origin: "SMC")
                    categorizedSensors[sensorType]?.append(sensorData)
                }
            } else if overlaySettings.showUnknownSensors {
                if let value = self.getValue(key) {
                    let sensorData = SMCSensorData(name: key, value: value, unit: unit, origin: "Unknown")
                    categorizedSensors[sensorType]?.append(sensorData)
                    print("Debug: Sensore sconosciuto trovato - Key: \(key), Valore: \(value), Unità: \(unit)")
                }
            }
        }

        return categorizedSensors
    }

    private func computeAverages() {
            let temperatureSensors = currentSensors[.temperature] ?? []
            
            // Filtra i sensori per ciascun gruppo
            let cpuPerformanceCores = temperatureSensors.filter { $0.name.starts(with: "CPU performance core") }
            let cpuEfficiencyCores = temperatureSensors.filter { $0.name.starts(with: "CPU efficiency core") }
            let gpuSensors = temperatureSensors.filter { $0.name.starts(with: "GPU") }
            let aneSensors = temperatureSensors.filter { $0.name.contains("Apple Neural Engine") }
            let batterySensors = temperatureSensors.filter { $0.name.contains("Battery") }
            
            // Calcola le medie
            let cpuPerformanceAvg = cpuPerformanceCores.compactMap { $0.value }.isEmpty ? nil : cpuPerformanceCores.compactMap { $0.value }.reduce(0, +) / Double(cpuPerformanceCores.count)
            let cpuEfficiencyAvg = cpuEfficiencyCores.compactMap { $0.value }.isEmpty ? nil : cpuEfficiencyCores.compactMap { $0.value }.reduce(0, +) / Double(cpuEfficiencyCores.count)
            let gpuAvg = gpuSensors.compactMap { $0.value }.isEmpty ? nil : gpuSensors.compactMap { $0.value }.reduce(0, +) / Double(gpuSensors.count)
            let aneAvg = aneSensors.compactMap { $0.value }.isEmpty ? nil : aneSensors.compactMap { $0.value }.reduce(0, +) / Double(aneSensors.count)
            let batteryAvg = batterySensors.compactMap { $0.value }.isEmpty ? nil : batterySensors.compactMap { $0.value }.reduce(0, +) / Double(batterySensors.count)
            
            // Rimuovi eventuali medie precedenti
            currentSensors[.temperature]?.removeAll { $0.name.contains("Average") }
            
            // Aggiungi le medie calcolate
            if let cpuPerformanceAvg = cpuPerformanceAvg {
                let avgSensor = SMCSensorData(name: "CPU Performance Cores Average", value: cpuPerformanceAvg, unit: "°C", origin: "SMC")
                currentSensors[.temperature]?.append(avgSensor)
            }

            if let cpuEfficiencyAvg = cpuEfficiencyAvg {
                let avgSensor = SMCSensorData(name: "CPU Efficiency Cores Average", value: cpuEfficiencyAvg, unit: "°C", origin: "SMC")
                currentSensors[.temperature]?.append(avgSensor)
            }

            if let gpuAvg = gpuAvg {
                let avgSensor = SMCSensorData(name: "GPU Average", value: gpuAvg, unit: "°C", origin: "SMC")
                currentSensors[.temperature]?.append(avgSensor)
            }

            if let aneAvg = aneAvg {
                let avgSensor = SMCSensorData(name: "Apple Neural Engine Average", value: aneAvg, unit: "°C", origin: "SMC")
                currentSensors[.temperature]?.append(avgSensor)
            }

            if let batteryAvg = batteryAvg {
                let avgSensor = SMCSensorData(name: "Battery Average", value: batteryAvg, unit: "°C", origin: "SMC")
                currentSensors[.temperature]?.append(avgSensor)
            }
        }
    
    public func getParsedSensors() -> [SensorType: [SMCSensorData]] {
        updateParsedSensors()
        return currentSensors
    }
    
    // MARK: - Nuove Funzioni per Gestione Ventole
    
    /// Determina quante ventole ci sono nel sistema e aggiorna il dizionario `fanDataDict`
    private func updateFanData() {
        let allKeys = self.getAllKeys()
        let fanKeyPattern = "^F(\\d+)(Ac|Mn|Mx|Tg)$"
        let regex = try? NSRegularExpression(pattern: fanKeyPattern, options: .caseInsensitive)
        
        var tempFanData: [Int: (ac: Double, mn: Double, mx: Double, tg: Double)] = [:]
        
        for key in allKeys {
            if let regex = regex {
                let matches = regex.matches(in: key, options: [], range: NSRange(location: 0, length: key.utf16.count))
                if let match = matches.first, match.numberOfRanges == 3,
                   let fanNumberRange = Range(match.range(at: 1), in: key),
                   let fanAttrRange = Range(match.range(at: 2), in: key) {
                    
                    let fanNumberString = String(key[fanNumberRange])
                    let fanAttr = String(key[fanAttrRange]).lowercased()
                    
                    if let fanNumber = Int(fanNumberString) {
                        if tempFanData[fanNumber] == nil {
                            tempFanData[fanNumber] = (ac: 0.0, mn: 0.0, mx: 0.0, tg: 0.0)
                        }
                        
                        if let value = self.getValue(key) {
                            switch fanAttr {
                            case "ac":
                                tempFanData[fanNumber]?.ac = value
                            case "mn":
                                tempFanData[fanNumber]?.mn = value
                            case "mx":
                                tempFanData[fanNumber]?.mx = value
                            case "tg":
                                tempFanData[fanNumber]?.tg = value
                            default:
                                continue
                            }
                        }
                    }
                }
            }
        }
        
        // Aggiorna `fanDataDict` senza ricrearlo da zero
        for (fanNumber, fanValues) in tempFanData {
            fanDataDict[fanNumber] = fanValues
        }
    }

    // MARK: - Sensors List

    internal let SensorsList: [String: [Sensor]] = [
        "temperature": [
            // Existing sensors
            Sensor(key: "TA%P", name: "Ambient %", type: .temperature),
            Sensor(key: "Th%H", name: "Heatpipe %", type: .temperature, platforms: [.intel]),
            Sensor(key: "TZ%C", name: "Thermal zone %", type: .temperature),
            Sensor(key: "TC0D", name: "CPU diode", type: .temperature, group: .CPU),
            Sensor(key: "TC0E", name: "CPU diode virtual", type: .temperature, group: .CPU),
            Sensor(key: "TC0F", name: "CPU diode filtered", type: .temperature, group: .CPU),
            Sensor(key: "TC0H", name: "CPU heatsink", type: .temperature, group: .CPU),
            Sensor(key: "TC0P", name: "CPU proximity", type: .temperature, group: .CPU),
            Sensor(key: "TCAD", name: "CPU package", type: .temperature, group: .CPU),
            Sensor(key: "TC%c", name: "CPU core %", type: .temperature, group: .CPU, average: true),
            Sensor(key: "TC%C", name: "CPU Core %", type: .temperature, group: .CPU, average: true),
            Sensor(key: "TCGC", name: "GPU Intel Graphics", type: .temperature, group: .GPU),
            Sensor(key: "TG0D", name: "GPU diode", type: .temperature, group: .GPU),
            Sensor(key: "TG0H", name: "GPU heatsink", type: .temperature, group: .GPU),
            Sensor(key: "TG0P", name: "GPU proximity", type: .temperature, group: .GPU),
            Sensor(key: "Tm0P", name: "Mainboard", type: .temperature, group: .system),
            Sensor(key: "Tp0P", name: "Powerboard", type: .temperature, group: .system, platforms: [.intel]),
            Sensor(key: "TB1T", name: "Battery", type: .temperature, group: .system, platforms: [.intel]),
            Sensor(key: "TW0P", name: "Airport", type: .temperature, group: .system),
            Sensor(key: "TL0P", name: "Display", type: .temperature, group: .system),
            Sensor(key: "TI%P", name: "Thunderbolt %", type: .temperature, group: .system),
            Sensor(key: "TH%A", name: "Disk % (A)", type: .temperature, group: .system),
            Sensor(key: "TH%B", name: "Disk % (B)", type: .temperature, group: .system),
            Sensor(key: "TH%C", name: "Disk % (C)", type: .temperature, group: .system),
            Sensor(key: "TTLD", name: "Thunderbolt left", type: .temperature, group: .system),
            Sensor(key: "TTRD", name: "Thunderbolt right", type: .temperature, group: .system),
            Sensor(key: "TN0D", name: "Northbridge diode", type: .temperature, group: .system),
            Sensor(key: "TN0H", name: "Northbridge heatsink", type: .temperature, group: .system),
            Sensor(key: "TN0P", name: "Northbridge proximity", type: .temperature, group: .system),
            Sensor(key: "TaLP", name: "Airflow left", type: .temperature, platforms: [.apple]),
            Sensor(key: "TaRF", name: "Airflow right", type: .temperature, platforms: [.apple]),
            Sensor(key: "TH0x", name: "NAND", type: .temperature, group: .system, platforms: [.apple]),
            Sensor(key: "TB1T", name: "Battery 1", type: .temperature, group: .system, platforms: [.apple]),
            Sensor(key: "TB2T", name: "Battery 2", type: .temperature, group: .system, platforms: [.apple]),
            Sensor(key: "TW0P", name: "Airport", type: .temperature, group: .system, platforms: [.apple]),

            // M1
            Sensor(key: "Tp09", name: "CPU efficiency core 1", type: .temperature, group: .CPU, platforms: [.m1], average: true),
            Sensor(key: "Tp0T", name: "CPU efficiency core 2", type: .temperature, group: .CPU, platforms: [.m1], average: true),
            Sensor(key: "Tp01", name: "CPU performance core 1", type: .temperature, group: .CPU, platforms: [.m1], average: true),
            Sensor(key: "Tp05", name: "CPU performance core 2", type: .temperature, group: .CPU, platforms: [.m1], average: true),
            Sensor(key: "Tp0D", name: "CPU performance core 3", type: .temperature, group: .CPU, platforms: [.m1], average: true),
            Sensor(key: "Tp0H", name: "CPU performance core 4", type: .temperature, group: .CPU, platforms: [.m1], average: true),
            Sensor(key: "Tp0L", name: "CPU performance core 5", type: .temperature, group: .CPU, platforms: [.m1], average: true),
            Sensor(key: "Tp0P", name: "CPU performance core 6", type: .temperature, group: .CPU, platforms: [.m1], average: true),
            Sensor(key: "Tp0X", name: "CPU performance core 7", type: .temperature, group: .CPU, platforms: [.m1], average: true),
            Sensor(key: "Tp0b", name: "CPU performance core 8", type: .temperature, group: .CPU, platforms: [.m1], average: true),

            Sensor(key: "Tg05", name: "GPU 1", type: .temperature, group: .GPU, platforms: [.m1], average: true),
            Sensor(key: "Tg0D", name: "GPU 2", type: .temperature, group: .GPU, platforms: [.m1], average: true),
            Sensor(key: "Tg0L", name: "GPU 3", type: .temperature, group: .GPU, platforms: [.m1], average: true),
            Sensor(key: "Tg0T", name: "GPU 4", type: .temperature, group: .GPU, platforms: [.m1], average: true),
            
            Sensor(key: "Ta1a", name: "Apple Neural Engine", type: .temperature, group: .ANE, platforms: [.m1], average: true),
            Sensor(key: "Ta1z", name: "Apple Neural Engine 2", type: .temperature, group: .ANE, platforms: [.m1], average: true),

            Sensor(key: "Tm02", name: "Memory 1", type: .temperature, group: .sensor, platforms: [.m1]),
            Sensor(key: "Tm06", name: "Memory 2", type: .temperature, group: .sensor, platforms: [.m1]),
            Sensor(key: "Tm08", name: "Memory 3", type: .temperature, group: .sensor, platforms: [.m1]),
            Sensor(key: "Tm09", name: "Memory 4", type: .temperature, group: .sensor, platforms: [.m1]),

            // M2
            Sensor(key: "Tp1h", name: "CPU efficiency core 1", type: .temperature, group: .CPU, platforms: [.m2], average: true),
            Sensor(key: "Tp1t", name: "CPU efficiency core 2", type: .temperature, group: .CPU, platforms: [.m2], average: true),
            Sensor(key: "Tp1p", name: "CPU efficiency core 3", type: .temperature, group: .CPU, platforms: [.m2], average: true),
            Sensor(key: "Tp1l", name: "CPU efficiency core 4", type: .temperature, group: .CPU, platforms: [.m2], average: true),

            Sensor(key: "Tp01", name: "CPU performance core 1", type: .temperature, group: .CPU, platforms: [.m2], average: true),
            Sensor(key: "Tp05", name: "CPU performance core 2", type: .temperature, group: .CPU, platforms: [.m2], average: true),
            Sensor(key: "Tp09", name: "CPU performance core 3", type: .temperature, group: .CPU, platforms: [.m2], average: true),
            Sensor(key: "Tp0D", name: "CPU performance core 4", type: .temperature, group: .CPU, platforms: [.m2], average: true),
            Sensor(key: "Tp0X", name: "CPU performance core 5", type: .temperature, group: .CPU, platforms: [.m2], average: true),
            Sensor(key: "Tp0b", name: "CPU performance core 6", type: .temperature, group: .CPU, platforms: [.m2], average: true),
            Sensor(key: "Tp0f", name: "CPU performance core 7", type: .temperature, group: .CPU, platforms: [.m2], average: true),
            Sensor(key: "Tp0j", name: "CPU performance core 8", type: .temperature, group: .CPU, platforms: [.m2], average: true),

            Sensor(key: "Tg0f", name: "GPU 1", type: .temperature, group: .GPU, platforms: [.m2], average: true),
            Sensor(key: "Tg0j", name: "GPU 2", type: .temperature, group: .GPU, platforms: [.m2], average: true),

            // M3
            Sensor(key: "Te05", name: "CPU efficiency core 1", type: .temperature, group: .CPU, platforms: [.m3], average: true),
            Sensor(key: "Te0L", name: "CPU efficiency core 2", type: .temperature, group: .CPU, platforms: [.m3], average: true),
            Sensor(key: "Te0P", name: "CPU efficiency core 3", type: .temperature, group: .CPU, platforms: [.m3], average: true),
            Sensor(key: "Te0S", name: "CPU efficiency core 4", type: .temperature, group: .CPU, platforms: [.m3], average: true),

            Sensor(key: "Tf04", name: "CPU performance core 1", type: .temperature, group: .CPU, platforms: [.m3], average: true),
            Sensor(key: "Tf09", name: "CPU performance core 2", type: .temperature, group: .CPU, platforms: [.m3], average: true),
            Sensor(key: "Tf0A", name: "CPU performance core 3", type: .temperature, group: .CPU, platforms: [.m3], average: true),
            Sensor(key: "Tf0B", name: "CPU performance core 4", type: .temperature, group: .CPU, platforms: [.m3], average: true),
            Sensor(key: "Tf0D", name: "CPU performance core 5", type: .temperature, group: .CPU, platforms: [.m3], average: true),
            Sensor(key: "Tf0E", name: "CPU performance core 6", type: .temperature, group: .CPU, platforms: [.m3], average: true),
            Sensor(key: "Tf44", name: "CPU performance core 7", type: .temperature, group: .CPU, platforms: [.m3], average: true),
            Sensor(key: "Tf49", name: "CPU performance core 8", type: .temperature, group: .CPU, platforms: [.m3], average: true),
            Sensor(key: "Tf4A", name: "CPU performance core 9", type: .temperature, group: .CPU, platforms: [.m3], average: true),
            Sensor(key: "Tf4B", name: "CPU performance core 10", type: .temperature, group: .CPU, platforms: [.m3], average: true),
            Sensor(key: "Tf4D", name: "CPU performance core 11", type: .temperature, group: .CPU, platforms: [.m3], average: true),
            Sensor(key: "Tf4E", name: "CPU performance core 12", type: .temperature, group: .CPU, platforms: [.m3], average: true),

            Sensor(key: "Tf14", name: "GPU 1", type: .temperature, group: .GPU, platforms: [.m3], average: true),
            Sensor(key: "Tf18", name: "GPU 2", type: .temperature, group: .GPU, platforms: [.m3], average: true),
            Sensor(key: "Tf19", name: "GPU 3", type: .temperature, group: .GPU, platforms: [.m3], average: true),
            Sensor(key: "Tf1A", name: "GPU 4", type: .temperature, group: .GPU, platforms: [.m3], average: true),
            Sensor(key: "Tf24", name: "GPU 5", type: .temperature, group: .GPU, platforms: [.m3], average: true),
            Sensor(key: "Tf28", name: "GPU 6", type: .temperature, group: .GPU, platforms: [.m3], average: true),
            Sensor(key: "Tf29", name: "GPU 7", type: .temperature, group: .GPU, platforms: [.m3], average: true),
            Sensor(key: "Tf2A", name: "GPU 8", type: .temperature, group: .GPU, platforms: [.m3], average: true),

            // M4
            Sensor(key: "Te05", name: "CPU efficiency core 1", type: .temperature, group: .CPU, platforms: [.m4], average: true),
            Sensor(key: "Tu0L", name: "CPU efficiency core 2", type: .temperature, group: .CPU, platforms: [.m4], average: true),
            Sensor(key: "Tu0P", name: "CPU efficiency core 3", type: .temperature, group: .CPU, platforms: [.m4], average: true),
            Sensor(key: "Te0S", name: "CPU efficiency core 4", type: .temperature, group: .CPU, platforms: [.m4], average: true),

            Sensor(key: "Tp01", name: "CPU performance core 1", type: .temperature, group: .CPU, platforms: [.m4], average: true),
            Sensor(key: "Tp05", name: "CPU performance core 2", type: .temperature, group: .CPU, platforms: [.m4], average: true),
            Sensor(key: "Tp0D", name: "CPU performance core 3", type: .temperature, group: .CPU, platforms: [.m4], average: true),
            Sensor(key: "Tp0X", name: "CPU performance core 4", type: .temperature, group: .CPU, platforms: [.m4], average: true),
            Sensor(key: "Tp0b", name: "CPU performance core 5", type: .temperature, group: .CPU, platforms: [.m4], average: true),
            Sensor(key: "Tp0f", name: "CPU performance core 6", type: .temperature, group: .CPU, platforms: [.m4], average: true),
            Sensor(key: "Tu44", name: "CPU performance core 7", type: .temperature, group: .CPU, platforms: [.m4], average: true),
            Sensor(key: "Tu49", name: "CPU performance core 8", type: .temperature, group: .CPU, platforms: [.m4], average: true),
            Sensor(key: "Tu4A", name: "CPU performance core 9", type: .temperature, group: .CPU, platforms: [.m4], average: true),
            Sensor(key: "Tu4B", name: "CPU performance core 10", type: .temperature, group: .CPU, platforms: [.m4], average: true),
            Sensor(key: "Tu4D", name: "CPU performance core 11", type: .temperature, group: .CPU, platforms: [.m4], average: true),
            Sensor(key: "Tu4E", name: "CPU performance core 12", type: .temperature, group: .CPU, platforms: [.m4], average: true),

            Sensor(key: "Tg0D", name: "GPU 1", type: .temperature, group: .GPU, platforms: [.m4], average: true),
            Sensor(key: "Tg0j", name: "GPU 2", type: .temperature, group: .GPU, platforms: [.m4], average: true),
            Sensor(key: "Tg0L", name: "GPU 3", type: .temperature, group: .GPU, platforms: [.m4], average: true),
            Sensor(key: "Tu1A", name: "GPU 4", type: .temperature, group: .GPU, platforms: [.m4], average: true),
            Sensor(key: "Tu24", name: "GPU 5", type: .temperature, group: .GPU, platforms: [.m4], average: true),
            Sensor(key: "Tu28", name: "GPU 6", type: .temperature, group: .GPU, platforms: [.m4], average: true),
            Sensor(key: "Tu29", name: "GPU 7", type: .temperature, group: .GPU, platforms: [.m4], average: true),
            Sensor(key: "Tu2A", name: "GPU 8", type: .temperature, group: .GPU, platforms: [.m4], average: true),
            Sensor(key: "Ta01", name: "Apple Neural Engine 1", type: .temperature, group: .ANE, platforms: [.m4], average: true),
            Sensor(key: "Ta05", name: "Apple Neural Engine 2", type: .temperature, group: .ANE, platforms: [.m4], average: true),
            Sensor(key: "Ta09", name: "Apple Neural Engine 3", type: .temperature, group: .ANE, platforms: [.m4], average: true),
            Sensor(key: "Ta0L", name: "Apple Neural Engine 4", type: .temperature, group: .ANE, platforms: [.m4], average: true),
            Sensor(key: "Ta0P", name: "Apple Neural Engine 5", type: .temperature, group: .ANE, platforms: [.m4], average: true),
            Sensor(key: "Ta0S", name: "Apple Neural Engine 6", type: .temperature, group: .ANE, platforms: [.m4], average: true),
            
            Sensor(key: "TaLP", name: "Airflow left", type: .temperature, group: .sensor, platforms: [.apple]),
            Sensor(key: "TaRF", name: "Airflow right", type: .temperature, group: .sensor, platforms: [.apple]),

            Sensor(key: "TH0x", name: "NAND", type: .temperature, group: .system, platforms: [.apple]),
            Sensor(key: "TB1T", name: "Battery 1", type: .temperature, group: .system, platforms: [.apple]),
            Sensor(key: "TB2T", name: "Battery 2", type: .temperature, group: .system, platforms: [.apple]),
            Sensor(key: "TW0P", name: "Airport", type: .temperature, group: .system, platforms: [.apple]),
        ],
        "voltage": [
            // Existing sensors
            Sensor(key: "VCAC", name: "CPU IA", type: .voltage, group: .CPU),
            Sensor(key: "VCSC", name: "CPU System Agent", type: .voltage, group: .CPU),
            Sensor(key: "VC%C", name: "CPU Core %", type: .voltage, group: .CPU),
            Sensor(key: "VCTC", name: "GPU Intel Graphics", type: .voltage, group: .GPU),
            Sensor(key: "VG0C", name: "GPU", type: .voltage, group: .GPU),
            Sensor(key: "VM0R", name: "Memory", type: .voltage, group: .system),
            Sensor(key: "Vb0R", name: "CMOS", type: .voltage, group: .system),
            Sensor(key: "VD0R", name: "DC In", type: .voltage),
            Sensor(key: "VP0R", name: "12V rail", type: .voltage),
            Sensor(key: "Vp0C", name: "12V vcc", type: .voltage),
            Sensor(key: "VV2S", name: "3V", type: .voltage),
            Sensor(key: "VR3R", name: "3.3V", type: .voltage),
            Sensor(key: "VV1S", name: "5V", type: .voltage),
            Sensor(key: "VV9S", name: "12V", type: .voltage),
            Sensor(key: "VeES", name: "PCI 12V", type: .voltage)
        ],
        "current": [
            // Existing sensors
            Sensor(key: "IC0R", name: "CPU High side", type: .current),
            Sensor(key: "IG0R", name: "GPU High side", type: .current),
            Sensor(key: "ID0R", name: "DC In", type: .current),
            Sensor(key: "IBAC", name: "Battery", type: .current)
        ],
        "power": [
            // Existing sensors
            Sensor(key: "PC0C", name: "CPU Core", type: .power, group: .CPU),
            Sensor(key: "PCAM", name: "CPU Core (IMON)", type: .power, group: .CPU),
            Sensor(key: "PCPC", name: "CPU Package", type: .power, group: .CPU),
            Sensor(key: "PCTR", name: "CPU Total", type: .power, group: .CPU),
            Sensor(key: "PCPT", name: "CPU Package total", type: .power, group: .CPU),
            Sensor(key: "PCPR", name: "CPU Package total (SMC)", type: .power, group: .CPU),
            Sensor(key: "PC0R", name: "CPU Computing high side", type: .power, group: .CPU),
            Sensor(key: "PC0G", name: "CPU GFX", type: .power, group: .CPU),
            Sensor(key: "PCEC", name: "CPU VccEDRAM", type: .power, group: .CPU),
            Sensor(key: "PCPG", name: "GPU Intel Graphics", type: .power, group: .GPU),
            Sensor(key: "PG0C", name: "GPU", type: .power, group: .GPU),
            Sensor(key: "PG0R", name: "GPU 1", type: .power, group: .GPU),
            Sensor(key: "PG1R", name: "GPU 2", type: .power, group: .GPU),
            Sensor(key: "PCGC", name: "Intel GPU", type: .power, group: .GPU),
            Sensor(key: "PCGM", name: "Intel GPU (IMON)", type: .power, group: .GPU),
            Sensor(key: "PC3C", name: "RAM", type: .power),
            Sensor(key: "PPBR", name: "Battery", type: .power),
            Sensor(key: "PDTR", name: "DC In", type: .power),
            Sensor(key: "PMTR", name: "Memory Total", type: .power),
            Sensor(key: "PSTR", name: "System Total", type: .power),
            Sensor(key: "PDBR", name: "Power Delivery Brightness", type: .power, platforms: [.m1, .m2, .m3, .m4])
        ]
    ]

    // MARK: - Unit Mapping

    func unit(for type: SensorType) -> String {
        switch type {
        case .temperature:
            return "°C"
        case .voltage:
            return "V"
        case .current:
            return "A"
        case .power:
            return "W"
        case .fan:
            return "RPM" // Assuming RPM is the correct unit for fans
        }
    }
}

