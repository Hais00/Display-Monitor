import Combine
import SwiftUI
import HotKey
public enum SensorLayoutStyle: String, CaseIterable, Identifiable {
    case singleLine
    case multipleLines

    public var id: String { self.rawValue }

    var description: String {
        switch self {
        case .singleLine:
            return "Same Row"
        case .multipleLines:
            return "New Row"
        }
    }
}
public enum OverlayPosition: String, CaseIterable, Identifiable {
    case topLeft
    case topCenter
    case topRight
    case centerRight
    case bottomRight
    case bottomCenter
    case bottomLeft
    case centerLeft

    public var id: String { self.rawValue }

    var description: String {
        switch self {
        case .topLeft:
            return "In Alto a Sinistra"
        case .topCenter:
            return "In Alto al Centro"
        case .topRight:
            return "In Alto a Destra"
        case .centerRight:
            return "A Meta Schermo a Destra"
        case .bottomRight:
            return "In Basso a Destra"
        case .bottomCenter:
            return "In Basso al Centro"
        case .bottomLeft:
            return "In Basso a Sinistra"
        case .centerLeft:
            return "A Meta Schermo a Sinistra"
        }
    }
}

public class SensorCategory: ObservableObject, Identifiable {
    public let id = UUID()
    @Published var name: String
    @Published var sensors: [AnySensor]
    @Published var isExpanded: Bool = true
    @Published var layoutStyle: SensorLayoutStyle = .multipleLines
    @Published var showCategoryName: Bool = true
    @Published var categoryNameColor: Color = .primary
    
    private var cancellables = Set<AnyCancellable>()

    init(name: String, sensors: [AnySensor] = []) {
        self.name = name
        self.sensors = sensors
        self.categoryNameColor = categoryNameColor
        setupSensorObservers()
    }

    private func setupSensorObservers() {
        // Observe changes in each sensor and forward them
        for sensor in sensors {
            sensor.objectWillChange
                .sink { [weak self] _ in
                    self?.objectWillChange.send()
                }
                .store(in: &cancellables)
        }
    }

    func addSensor(_ sensor: AnySensor) {
        sensors.append(sensor)
        sensor.objectWillChange
            .sink { [weak self] _ in
                self?.objectWillChange.send()
            }
            .store(in: &cancellables)
    }

    func removeSensor(_ sensor: AnySensor) {
        if let index = sensors.firstIndex(where: { $0.id == sensor.id }) {
            sensors.remove(at: index)
            // Optionally remove the associated cancellable if you keep track of them individually
        }
    }
}
extension Notification.Name {
    static let toggleMetalHUD = Notification.Name("toggleMetalHUD")
}

public class OverlaySettings: ObservableObject {
    var overlayHotKey: HotKey?
    var sensorsHotKey: HotKey?
    

    @Published var isOverlayActive: Bool = false {
        didSet {
            if !isForcingRefresh && !isInitializing {
                saveOverlaySettings()
            }
        }
    }
    @Published var overlayScale: CGFloat = 1.0 {
            didSet {
                if !isForcingRefresh && !isInitializing {
                    saveOverlaySettings()
                }
            }
        }
    
    private let overlayScaleKey = "overlayScale"
    @Published var overlayPosition: OverlayPosition = .topLeft {
            didSet {
                if !isForcingRefresh && !isInitializing {
                    saveOverlaySettings()
                    refreshOverlayPosition()
                }
            }
        }

        private let overlayPositionKey = "overlayPosition"
    @Published var overlayShortcut: String = "O" {
        didSet {
            setOverlayHotKey()
            saveShortcutToDefaults(key: "overlayShortcut", shortcut: overlayShortcut)
        }
    }

    @Published var sensorsShortcut: String = "S" {
        didSet {
            setSensorsHotKey()
            saveShortcutToDefaults(key: "sensorsShortcut", shortcut: sensorsShortcut)
        }
    }

    @Published var showUnknownSensors: Bool = false {
        didSet {
            print("Debug: Flag `showUnknownSensors` aggiornato a \(showUnknownSensors)")
            saveOverlaySettings()
            updateSensorFetching()
        }
    }

    @Published var overlayBackgroundColor: Color = Color.black {
        didSet {
            if !isInitializing {
                saveOverlaySettings()
            }
        }
    }

    @Published var overlayTextColor: Color = Color.white {
        didSet {
            if !isInitializing {
                saveOverlaySettings()
            }
        }
    }

    @Published var overlayOpacity: Double = 0.7 {
        didSet {
            if !isInitializing {
                saveOverlaySettings()
            }
        }
    }
    @Published var isMetalHUDActive: Bool = true {
            didSet {
                NotificationCenter.default.post(name: .toggleMetalHUD, object: isMetalHUDActive)
                saveOverlaySettings()
            }
        }
    @Published var overlayCornerRadius: Double = 10.0 {
            didSet {
                if !isForcingRefresh && !isInitializing {
                    saveOverlaySettings()
                }
            }
        }
    // Aggiunta delle categorie personalizzate
    @Published var customCategories: [SensorCategory] = []
    private let overlayCornerRadiusKey = "overlayCornerRadius"
    private var previousSavedLayout: [String] = []
    private var isSavingLayout = false
    private let layoutKey = "sensorLayoutOrder"

    private var isInitializing = true
    private var isForcingRefresh = false
    var hidSensors: HIDSensors
    var powermetricsSensors: PowermetricsSensors
    var smcSensors: SMCSensors
    private var cancellables = Set<AnyCancellable>()

    init(hidSensors: HIDSensors, powermetricsSensors: PowermetricsSensors, smcSensors: SMCSensors) {
        self.hidSensors = hidSensors
        self.powermetricsSensors = powermetricsSensors
        self.smcSensors = smcSensors
        print("Debug: Inizializzazione di OverlaySettings - Istanza: \(Unmanaged.passUnretained(self).toOpaque())")
        
        setOverlayHotKey()
        setSensorsHotKey()
    }

    private let isOverlayActiveKey = "isOverlayActive"
    private let overlayOpacityKey = "overlayOpacity"
    private let overlayBackgroundColorKey = "overlayBackgroundColor"
    private let overlayTextColorKey = "overlayTextColor"
    private let showUnknownSensorsKey = "showUnknownSensors"
    private let customCategoriesKey = "customCategories"
    @Published var allSelectedSensors: [AnySensor] = []
    @Published var orderedSensors: [String] = []
     func setupCategoriesObserver() {
        // Osserva le modifiche a customCategories
        $customCategories
            .sink { [weak self] categories in
                guard let self = self else { return }
                // Evita di salvare se categories è vuoto e non ci sono categorie salvate
                if categories.isEmpty, UserDefaults.standard.object(forKey: self.customCategoriesKey) == nil {
                    return
                }
                self.saveOverlaySettings()
            }
            .store(in: &cancellables)
    }

    func fontName(from font: Font) -> String {
        if font == .body { return "body" }
        else if font == .caption { return "caption" }
        else if font == .footnote { return "footnote" }
        else if font == .headline { return "headline" }
        else if font == .subheadline { return "subheadline" }
        else if font == .title { return "title" }
        else if font == .largeTitle { return "largeTitle" }
        else { return "body" }
    }

    func font(from name: String) -> Font {
        switch name {
        case "body": return .body
        case "caption": return .caption
        case "footnote": return .footnote
        case "headline": return .headline
        case "subheadline": return .subheadline
        case "title": return .title
        case "largeTitle": return .largeTitle
        default: return .body
        }
    }

    func loadOverlaySettings() {
        
        
        // Carica gli shortcut
        loadShortcutsFromDefaults()

        // Carica lo stato dell'overlay
        if UserDefaults.standard.object(forKey: isOverlayActiveKey) != nil {
            isOverlayActive = UserDefaults.standard.bool(forKey: isOverlayActiveKey)
        }

        // Carica altre impostazioni come overlayOpacity, colori, etc.
        if UserDefaults.standard.object(forKey: overlayOpacityKey) != nil {
            overlayOpacity = UserDefaults.standard.double(forKey: overlayOpacityKey)
        }
        if UserDefaults.standard.object(forKey: "isMetalHUDActive") != nil {
                    isMetalHUDActive = UserDefaults.standard.bool(forKey: "isMetalHUDActive")
                }
        if let backgroundColorData = UserDefaults.standard.data(forKey: overlayBackgroundColorKey),
           let nsBackgroundColor = try? NSKeyedUnarchiver.unarchiveTopLevelObjectWithData(backgroundColorData) as? NSColor {
            overlayBackgroundColor = Color(nsBackgroundColor)
        }

        if let textColorData = UserDefaults.standard.data(forKey: overlayTextColorKey),
           let nsTextColor = try? NSKeyedUnarchiver.unarchiveTopLevelObjectWithData(textColorData) as? NSColor {
            overlayTextColor = Color(nsTextColor)
        }
        if UserDefaults.standard.object(forKey: overlayCornerRadiusKey) != nil {
                    overlayCornerRadius = UserDefaults.standard.double(forKey: overlayCornerRadiusKey)
                }
        if UserDefaults.standard.object(forKey: showUnknownSensorsKey) != nil {
            showUnknownSensors = UserDefaults.standard.bool(forKey: showUnknownSensorsKey)
        }
        if let savedPosition = UserDefaults.standard.string(forKey: overlayPositionKey),
                   let position = OverlayPosition(rawValue: savedPosition) {
                    overlayPosition = position
                }
        // Configura gli HotKey dopo aver caricato gli shortcut
        setOverlayHotKey()
        setSensorsHotKey()

        // Carica le categorie personalizzate
        loadCustomCategories()
        isInitializing = false
    }
    func loadLayout() {
        print("Debug: Caricamento del layout e delle impostazioni dei sensori iniziato")
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            
            // Carica le categorie personalizzate, che includono l'ordine e le proprietà dei sensori
            self.loadCustomCategories()
            
            // Aggiorna i sensori selezionati in base alle categorie caricate
            self.updateSelectedSensors()
            
            // Carica altre impostazioni come isOverlayActive, overlayOpacity, ecc.
            if UserDefaults.standard.object(forKey: self.isOverlayActiveKey) != nil {
                self.isOverlayActive = UserDefaults.standard.bool(forKey: self.isOverlayActiveKey)
                print("Debug: isOverlayActive caricato: \(self.isOverlayActive)")
            }
            
            if UserDefaults.standard.object(forKey: self.overlayOpacityKey) != nil {
                self.overlayOpacity = UserDefaults.standard.double(forKey: self.overlayOpacityKey)
                print("Debug: overlayOpacity caricato: \(self.overlayOpacity)")
            }
            
            // **Caricamento della Posizione dell'Overlay**
            if let savedPosition = UserDefaults.standard.string(forKey: self.overlayPositionKey),
               let position = OverlayPosition(rawValue: savedPosition) {
                self.overlayPosition = position
                print("Debug: overlayPosition caricato: \(self.overlayPosition.description)")
            } else {
                print("Debug: Nessuna posizione salvata per l'overlay, utilizzando posizione di default.")
            }
            
            // Carica il colore di sfondo dell'overlay
            if let backgroundColorData = UserDefaults.standard.data(forKey: self.overlayBackgroundColorKey),
               let nsBackgroundColor = try? NSKeyedUnarchiver.unarchiveTopLevelObjectWithData(backgroundColorData) as? NSColor {
                self.overlayBackgroundColor = Color(nsBackgroundColor)
                print("Debug: overlayBackgroundColor caricato")
            } else {
                print("Debug: Nessun colore di sfondo salvato per l'overlay.")
            }
            
            // Carica il colore del testo dell'overlay
            if let textColorData = UserDefaults.standard.data(forKey: self.overlayTextColorKey),
               let nsTextColor = try? NSKeyedUnarchiver.unarchiveTopLevelObjectWithData(textColorData) as? NSColor {
                self.overlayTextColor = Color(nsTextColor)
                print("Debug: overlayTextColor caricato")
            } else {
                print("Debug: Nessun colore del testo salvato per l'overlay.")
            }
            
            // Carica il raggio degli angoli dell'overlay
            if UserDefaults.standard.object(forKey: self.overlayCornerRadiusKey) != nil {
                self.overlayCornerRadius = UserDefaults.standard.double(forKey: self.overlayCornerRadiusKey)
                print("Debug: overlayCornerRadius caricato: \(self.overlayCornerRadius)")
            }
            if UserDefaults.standard.object(forKey: overlayScaleKey) != nil {
                    overlayScale = CGFloat(UserDefaults.standard.double(forKey: overlayScaleKey))
                    print("Debug: overlayScale caricato: \(overlayScale)")
                }
            // Carica il flag per mostrare sensori sconosciuti
            if UserDefaults.standard.object(forKey: self.showUnknownSensorsKey) != nil {
                self.showUnknownSensors = UserDefaults.standard.bool(forKey: self.showUnknownSensorsKey)
                print("Debug: showUnknownSensors caricato: \(self.showUnknownSensors)")
            }
            
            // Carica le categorie personalizzate
            self.loadCustomCategories()
            
            // Configura gli HotKey dopo aver caricato gli shortcut
            self.setOverlayHotKey()
            self.setSensorsHotKey()
            
            // Aggiorna il fetching dei sensori in base alle impostazioni caricate
            self.updateSensorFetching()
            
            print("Debug: Layout e impostazioni dei sensori caricati con successo")
        }
    }



    func saveOverlaySettings() {
        guard !isSavingLayout else { return }
        isSavingLayout = true

        UserDefaults.standard.set(isOverlayActive, forKey: isOverlayActiveKey)
        UserDefaults.standard.set(overlayOpacity, forKey: overlayOpacityKey)

        if let backgroundColorData = try? NSKeyedArchiver.archivedData(withRootObject: NSColor(overlayBackgroundColor), requiringSecureCoding: false) {
            UserDefaults.standard.set(backgroundColorData, forKey: overlayBackgroundColorKey)
        } else {
            print("Errore: Impossibile serializzare overlayBackgroundColor.")
        }

        if let textColorData = try? NSKeyedArchiver.archivedData(withRootObject: NSColor(overlayTextColor), requiringSecureCoding: false) {
            UserDefaults.standard.set(textColorData, forKey: overlayTextColorKey)
        } else {
            print("Errore: Impossibile serializzare overlayTextColor.")
        }
        UserDefaults.standard.set(overlayCornerRadius, forKey: overlayCornerRadiusKey)
        UserDefaults.standard.set(isMetalHUDActive, forKey: "isMetalHUDActive")
        UserDefaults.standard.set(showUnknownSensors, forKey: showUnknownSensorsKey)
        UserDefaults.standard.set(overlayPosition.rawValue, forKey: overlayPositionKey)
        UserDefaults.standard.set(Double(overlayScale), forKey: overlayScaleKey)
        // Salva le categorie personalizzate
        saveCustomCategories()

        // Debug: conferma il salvataggio
        print("Debug: Overlay settings salvati in UserDefaults")
            print("Debug: isOverlayActive=\(isOverlayActive), overlayOpacity=\(overlayOpacity)")
            print("Debug: showUnknownSensors=\(showUnknownSensors)")

        isSavingLayout = false
    }

    func saveLayout() {
        guard !isSavingLayout else { return }
        isSavingLayout = true

        // Salva l'ordine dei sensori all'interno delle categorie
        saveCustomCategories()

        isSavingLayout = false
    }
    func refreshOverlayPosition() {
            HUDWindow.closeAllHUDWindows()
            HUDWindow.createHUDWindows(overlaySettings: self)
        }
    func saveCustomCategories() {
        let categoriesData = customCategories.map { category -> [String: Any] in
            let sensorsData = category.sensors.map { sensor -> [String: Any] in
                var sensorDict: [String: Any] = [
                    "id": sensor.id.uuidString,
                    "name": sensor.name,
                    // Remove or comment out the following line as 'sensorType' no longer exists
                    // "type": sensor.sensorType,
                    "sensorKind": sensor.sensorKind.rawValue,
                    "customDisplayName": sensor.customDisplayName,
                    "isActive": sensor.isActive,
                    "showName": sensor.showName,
                    "useCustomName": sensor.useCustomName
                ]

                // Save the font name
                sensorDict["fontName"] = fontName(from: sensor.font)

                // Convert colors to RGB components
                if let nsNameColor = NSColor(sensor.nameColor).usingColorSpace(.sRGB) {
                    let nameColorComponents: [String: CGFloat] = [
                        "red": nsNameColor.redComponent,
                        "green": nsNameColor.greenComponent,
                        "blue": nsNameColor.blueComponent,
                        "alpha": nsNameColor.alphaComponent
                    ]
                    sensorDict["nameColor"] = nameColorComponents
                } else {
                    print("Errore: Impossibile convertire nameColor in spazio colore sRGB.")
                }

                if let nsValueColor = NSColor(sensor.valueColor).usingColorSpace(.sRGB) {
                    let valueColorComponents: [String: CGFloat] = [
                        "red": nsValueColor.redComponent,
                        "green": nsValueColor.greenComponent,
                        "blue": nsValueColor.blueComponent,
                        "alpha": nsValueColor.alphaComponent
                    ]
                    sensorDict["valueColor"] = valueColorComponents
                } else {
                    print("Errore: Impossibile convertire valueColor in spazio colore sRGB.")
                }

                return sensorDict
            }
            var categoryDict: [String: Any] = [
                "id": category.id.uuidString,
                "name": category.name,
                "sensors": sensorsData,
                "layoutStyle": category.layoutStyle.rawValue,
                "showCategoryName": category.showCategoryName
            ]

            // Save categoryNameColor
            if let nsCategoryNameColor = NSColor(category.categoryNameColor).usingColorSpace(.sRGB) {
                let categoryNameColorComponents: [String: CGFloat] = [
                    "red": nsCategoryNameColor.redComponent,
                    "green": nsCategoryNameColor.greenComponent,
                    "blue": nsCategoryNameColor.blueComponent,
                    "alpha": nsCategoryNameColor.alphaComponent
                ]
                categoryDict["categoryNameColor"] = categoryNameColorComponents
            } else {
                print("Errore: Impossibile convertire categoryNameColor in spazio colore sRGB.")
            }

            return categoryDict
        }
        UserDefaults.standard.set(categoriesData, forKey: customCategoriesKey)
    }







    private func loadCustomCategories() {
        print("Inizio caricamento categorie personalizzate")
        if let categoriesData = UserDefaults.standard.array(forKey: customCategoriesKey) as? [[String: Any]] {
            print("Dati categorie caricati: \(categoriesData)")
            self.customCategories = categoriesData.compactMap { categoryDict -> SensorCategory? in
                guard let name = categoryDict["name"] as? String,
                      let sensorsData = categoryDict["sensors"] as? [[String: Any]] else {
                    print("Categoria mancante di nome o dati sensori")
                    return nil
                }
                let sensors: [AnySensor] = sensorsData.compactMap { sensorDict -> AnySensor? in
                    guard let sensorName = sensorDict["name"] as? String,
                          let sensorKindRaw = sensorDict["sensorKind"] as? String,
                          let sensorKind = SensorKind(rawValue: sensorKindRaw),
                          let customDisplayName = sensorDict["customDisplayName"] as? String,
                          let isActive = sensorDict["isActive"] as? Bool else {
                        print("Sensore mancante di nome, kind, display name o stato attivo")
                        return nil
                    }

                    if let sensorProtocol = findSensorByName(name: sensorName, sensorKind: sensorKind) {
                        let sensor = AnySensor(sensorProtocol)
                        sensor.customDisplayName = customDisplayName
                        sensor.isActive = isActive
                        sensor.showName = sensorDict["showName"] as? Bool ?? true
                        sensor.useCustomName = sensorDict["useCustomName"] as? Bool ?? false

                        // Carica nameColor
                        if let nameColorComponents = sensorDict["nameColor"] as? [String: CGFloat],
                           let red = nameColorComponents["red"],
                           let green = nameColorComponents["green"],
                           let blue = nameColorComponents["blue"],
                           let alpha = nameColorComponents["alpha"] {
                            let nsNameColor = NSColor(red: red, green: green, blue: blue, alpha: alpha)
                            sensor.nameColor = Color(nsNameColor)
                        } else {
                            print("Errore nel caricamento nameColor")
                        }

                        // Carica valueColor
                        if let valueColorComponents = sensorDict["valueColor"] as? [String: CGFloat],
                           let red = valueColorComponents["red"],
                           let green = valueColorComponents["green"],
                           let blue = valueColorComponents["blue"],
                           let alpha = valueColorComponents["alpha"] {
                            let nsValueColor = NSColor(red: red, green: green, blue: blue, alpha: alpha)
                            sensor.valueColor = Color(nsValueColor)
                        } else {
                            print("Errore nel caricamento valueColor")
                        }

                        // Carica font
                        if let fontName = sensorDict["fontName"] as? String {
                            sensor.font = font(from: fontName)
                        }
                        return sensor
                    }
                    print("Sensore non trovato per il nome: \(sensorName) e kind: \(sensorKindRaw)")
                    return nil
                }
                let category = SensorCategory(name: name, sensors: sensors)
                if let layoutStyleRaw = categoryDict["layoutStyle"] as? String,
                   let layoutStyle = SensorLayoutStyle(rawValue: layoutStyleRaw) {
                    category.layoutStyle = layoutStyle
                }
                if let showCategoryName = categoryDict["showCategoryName"] as? Bool {
                    category.showCategoryName = showCategoryName
                }

                // Carica categoryNameColor
                if let categoryNameColorComponents = categoryDict["categoryNameColor"] as? [String: CGFloat],
                   let red = categoryNameColorComponents["red"],
                   let green = categoryNameColorComponents["green"],
                   let blue = categoryNameColorComponents["blue"],
                   let alpha = categoryNameColorComponents["alpha"] {
                    let nsCategoryNameColor = NSColor(red: red, green: green, blue: blue, alpha: alpha)
                    category.categoryNameColor = Color(nsCategoryNameColor)
                } else {
                    print("Errore nel caricamento categoryNameColor")
                }

                print("Categoria caricata: \(category.name) con \(sensors.count) sensori")
                return category
            }
            print("Tutte le categorie personalizzate sono state caricate")
        } else {
            print("Nessuna categoria personalizzata trovata in UserDefaults")
        }
    }





    func updateSensorFetching() {
        if showUnknownSensors {
            hidSensors.fetchAdditionalSensors()
        } else {
            hidSensors.clearAdditionalSensors()
        }
    }

    func updateSelectedSensors() {
        DispatchQueue.main.async { [weak self] in
            guard let self = self else { return }
            
            // Aggiorna i sensori selezionati in base alle categorie personalizzate
            self.allSelectedSensors = self.customCategories.flatMap { $0.sensors.filter { $0.isActive } }
            self.orderedSensors = self.allSelectedSensors.map { $0.name }
        }
    }



    // Computed Properties per tutti i sensori
    var allTemperatureSensors: [TemperatureSensor] {
        return hidSensors.temperatureSensors + smcSensors.temperatureSensors
    }

    var allVoltageSensors: [VoltageSensor] {
        return hidSensors.voltageSensors + smcSensors.voltageSensors
    }

    var allCurrentSensors: [CurrentSensor] {
        return hidSensors.currentSensors + smcSensors.currentSensors
    }

    var allPowerSensors: [PowerSensor] {
        return hidSensors.powerSensors + powermetricsSensors.powerData + smcSensors.powerSensors
    }

    var allFrequencySensors: [FrequencySensor] {
        return powermetricsSensors.frequencyData
    }

    var allUsageSensors: [UsageSensor] {
        return powermetricsSensors.usageData
    }

    var allFanSensors: [FanSensor] {
        return smcSensors.fanSensors
    }

    func setOff() {
        print("Debug: Impostazione overlay su Off")
        isInitializing = false
    }

    func refreshOverlay() {
        print("Debug: refreshOverlay chiamato")
        isForcingRefresh = true
        isOverlayActive.toggle()
        isOverlayActive.toggle()
        isForcingRefresh = false
    }

    func setupSensorObservers() {
        Publishers.MergeMany(
            hidSensors.objectWillChange,
            powermetricsSensors.objectWillChange,
            smcSensors.objectWillChange
        )
        .receive(on: RunLoop.main)
        .sink { [weak self] _ in
            self?.updateSelectedSensors()
            self?.objectWillChange.send()
        }
        .store(in: &cancellables)
    }


    // Funzione helper per trovare un sensore per nome
    func findSensorByName(name: String, sensorKind: SensorKind) -> (any SensorProtocol)? {
        let tempSensors = allTemperatureSensors as [any SensorProtocol]
        let voltageSensors = allVoltageSensors as [any SensorProtocol]
        let currentSensors = allCurrentSensors as [any SensorProtocol]
        let powerSensors = allPowerSensors as [any SensorProtocol]
        let frequencySensors = allFrequencySensors as [any SensorProtocol]
        let usageSensors = allUsageSensors as [any SensorProtocol]
        let fanSensors = allFanSensors as [any SensorProtocol]

        let allSensors = tempSensors + voltageSensors + currentSensors + powerSensors + frequencySensors + usageSensors + fanSensors
        return allSensors.first { $0.name == name && $0.sensorKind == sensorKind }
    }


}

extension OverlaySettings {
    // Funzione per creare un HotKey
    private func createHotKey(from shortcut: String, handler: @escaping () -> Void) -> HotKey? {
        guard let character = shortcut.uppercased().first,
              let key = Key(character: character) else {
            print("Errore: Tasto non valido.")
            return nil
        }

        let modifiers: NSEvent.ModifierFlags = [.command, .shift]
        let hotkey = HotKey(key: key, modifiers: modifiers)
        hotkey.keyDownHandler = handler
        return hotkey
    }

    // Configura l'HotKey per Overlay
    func setOverlayHotKey() {
        overlayHotKey?.isPaused = true
        overlayHotKey = createHotKey(from: overlayShortcut) { [weak self] in
            self?.toggleOverlay()
        }
    }

    // Configura l'HotKey per la vista dei sensori
    func setSensorsHotKey() {
        sensorsHotKey?.isPaused = true
        sensorsHotKey = createHotKey(from: sensorsShortcut) { [weak self] in
            self?.showSensorsView()
        }
    }

    // Azioni per gli HotKey
    func toggleOverlay() {
        isOverlayActive.toggle()
    }


    private func showSensorsView() {
        if let appDelegate = NSApp.delegate as? AppDelegate {
            appDelegate.showSensorsWindow()
        }
    }

    // Salva gli shortcut in UserDefaults
    private func saveShortcutToDefaults(key: String, shortcut: String) {
        UserDefaults.standard.set(shortcut, forKey: key)
    }

    // Carica gli shortcut da UserDefaults
    private func loadShortcutsFromDefaults() {
        if let savedOverlayShortcut = UserDefaults.standard.string(forKey: "overlayShortcut") {
            overlayShortcut = savedOverlayShortcut
        }
        if let savedSensorsShortcut = UserDefaults.standard.string(forKey: "sensorsShortcut") {
            sensorsShortcut = savedSensorsShortcut
        }
    }
}
