import SwiftUI
import Combine

struct OverlaySettingsView: View {
    @EnvironmentObject var overlaySettings: OverlaySettings
    @State private var showingSensorSelection = false
    @State private var selectedCategory: SensorCategory?

    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                // Section for customizing the Overlay
                sectionContainer {
                    OverlayCustomizationView()
                }

                // Section for managing custom categories
                sectionContainer {
                    CustomCategoriesView(selectedCategory: $selectedCategory, showingSensorSelection: $showingSensorSelection)
                }
            }
            .padding()
        }
        .sheet(isPresented: $showingSensorSelection) {
            if let category = selectedCategory {
                SensorSelectionView(category: category, isPresented: $showingSensorSelection)
                    .environmentObject(overlaySettings)
            }
        }
        .onAppear {
            print("OverlaySettingsView appeared with sensors:")
            printSensors()
        }
    }

    private func printSensors() {
        print("Available sensors:")
        // You can print the available sensors here if necessary
    }

    // Helper function for modern section styling
    @ViewBuilder
    private func sectionContainer<Content: View>(@ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            content()
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(Color.gray.opacity(0.1))
                .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
        )
    }
}

// Subview for Overlay Activation
struct OverlayActivationView: View {
    @EnvironmentObject var overlaySettings: OverlaySettings

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Overlay")
                .font(.title3).bold()
            Toggle(isOn: $overlaySettings.isOverlayActive) {
                Text("Enable Overlay")
                    .font(.body)
            }
            .onChange(of: overlaySettings.isOverlayActive) { isActive in
                print("Overlay active: \(isActive)")
            }
        }
    }
}

struct PositionSelectorView: View {
    @Binding var selectedPosition: OverlayPosition

    // Dimensioni e padding
    private let circleSize: CGFloat = 20
    private let padding: CGFloat = 20

    var body: some View {
        GeometryReader { geometry in
            let width = geometry.size.width
            let height = geometry.size.height

            ZStack {
                // Rettangolo leggermente stondato
                RoundedRectangle(cornerRadius: 8)
                    .stroke(Color.gray.opacity(0.3), lineWidth: 2)
                    .background(
                        RoundedRectangle(cornerRadius: 8)
                            .fill(Color.white.opacity(0.05))
                    )
                
                // Pallini posizionati esattamente
                // Top Left
                positionDot(position: .topLeft, x: padding, y: padding)
                
                // Top Center
                positionDot(position: .topCenter, x: width / 2, y: padding)
                
                // Top Right
                positionDot(position: .topRight, x: width - padding, y: padding)
                
                // Center Left
                positionDot(position: .centerLeft, x: padding, y: height / 2)
                
                // Center Right
                positionDot(position: .centerRight, x: width - padding, y: height / 2)
                
                // Bottom Left
                positionDot(position: .bottomLeft, x: padding, y: height - padding)
                
                // Bottom Center
                positionDot(position: .bottomCenter, x: width / 2, y: height - padding)
                
                // Bottom Right
                positionDot(position: .bottomRight, x: width - padding, y: height - padding)
            }
        }
        .frame(height: 200) // Altezza del container
    }

    // Funzione helper per creare i pallini
    private func positionDot(position: OverlayPosition, x: CGFloat, y: CGFloat) -> some View {
        Button(action: {
            withAnimation {
                selectedPosition = position
            }
        }) {
            Circle()
                .fill(selectedPosition == position ? Color.blue : Color.gray.opacity(0.3))
                .frame(width: circleSize, height: circleSize)
                .overlay(
                    Circle()
                        .stroke(Color.blue, lineWidth: selectedPosition == position ? 2 : 0)
                )
                .scaleEffect(selectedPosition == position ? 1.2 : 1.0)
                .animation(.easeInOut, value: selectedPosition)
        }
        .position(x: x, y: y)
        .buttonStyle(PlainButtonStyle())
        .accessibilityLabel(Text(position.description))
        .accessibilityAddTraits(selectedPosition == position ? .isSelected : .isButton)
    }
}

// Sottoview per la personalizzazione dell'Overlay
struct OverlayCustomizationView: View {
    @EnvironmentObject var overlaySettings: OverlaySettings

    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            // Container per i Toggle "Overlay" e "Metal HUD" nella stessa riga
            HStack {
                Toggle(isOn: $overlaySettings.isOverlayActive) {
                    Text("Overlay")
                        .font(.body)
                }
                .toggleStyle(SwitchToggleStyle(tint: .blue))
                .onChange(of: overlaySettings.isOverlayActive) { isActive in
                    print("Overlay active: \(isActive)")
                }

                Spacer() // Spazio flessibile tra i due toggle

                Toggle(isOn: $overlaySettings.isMetalHUDActive) {
                    Text("Metal HUD")
                        .font(.body)
                }
                .toggleStyle(SwitchToggleStyle(tint: .blue))
                .onChange(of: overlaySettings.isMetalHUDActive) { isActive in
                    print("Metal HUD active: \(isActive)")
                }
            }
            .padding(.vertical, 5) // Opzionale: Aggiunge padding verticale agli toggle

            // Container unificato per PositionSelectorView e gli slider
            VStack(alignment: .leading, spacing: 20) {
                // PositionSelectorView senza label
                PositionSelectorView(selectedPosition: $overlaySettings.overlayPosition)
                    .padding(.top, 5)

                // Sezione per la scala dell'Overlay
                VStack(alignment: .leading, spacing: 10) {
                    HStack {
                        Slider(value: $overlaySettings.overlayScale, in: 0.5...2.0, step: 0.1)
                            .onChange(of: overlaySettings.overlayScale) { scale in
                                print("Overlay Scale: \(scale)x")
                            }
                        Text("Scale: \(String(format: "%.1f", overlaySettings.overlayScale))x")
                            .font(.footnote)
                            .foregroundColor(.secondary)
                    }
                }
                .padding(.top, 20)

                // Aggiunta di spazio aggiuntivo prima del ColorPicker
                VStack(alignment: .leading, spacing: 10) {
                    HStack {
                        ColorPicker("", selection: $overlaySettings.overlayBackgroundColor)
                            .labelsHidden()
                        Text("Background Color")
                            .font(.body)
                    }
                }
                .padding(.top, 20) // Aggiunge 10 punti di padding sopra il ColorPicker

                // Sezione per l'opacità
                VStack(alignment: .leading, spacing: 10) {
                    Slider(value: $overlaySettings.overlayOpacity, in: 0...1)
                        .padding(.vertical)
                        .onChange(of: overlaySettings.overlayOpacity) { opacity in
                            print("Overlay Opacity: \(Int(opacity * 100))%")
                        }
                    Text("Overlay Opacity: \(Int(overlaySettings.overlayOpacity * 100))%")
                        .font(.footnote)
                        .foregroundColor(.secondary)
                }

                // Sezione per il raggio degli angoli
                VStack(alignment: .leading, spacing: 10) {
                    Slider(value: $overlaySettings.overlayCornerRadius, in: 0...40, step: 1)
                        .padding(.vertical)
                        .onChange(of: overlaySettings.overlayCornerRadius) { radius in
                            print("Overlay Corner Radius: \(radius)")
                        }
                    Text("Overlay Corner Radius: \(Int(overlaySettings.overlayCornerRadius))")
                        .font(.footnote)
                        .foregroundColor(.secondary)
                }
            }
        }
        .padding()
    }
}




// CustomCategoriesView
struct CustomCategoriesView: View {
    @EnvironmentObject var overlaySettings: OverlaySettings
    @Binding var selectedCategory: SensorCategory?
    @Binding var showingSensorSelection: Bool

    @State private var isPresentingNewCategorySheet = false
    @State private var newCategoryName = ""

    var body: some View {
        VStack(alignment: .leading) {
            HStack {
                Text("Categories")
                    .font(.title3).bold()
                Spacer()
                Button(action: {
                    // Mostra il foglio per creare una nuova categoria
                    newCategoryName = ""
                    isPresentingNewCategorySheet = true
                }) {
                    Image(systemName: "plus")
                }
            }
            .padding(.bottom, 5)

            // Sostituisci la List con ScrollView e LazyVStack
            ScrollView(showsIndicators: false) { // Nasconde gli indicatori di scorrimento
                LazyVStack(spacing: 10) { // Aggiungi spazio tra le categorie se desiderato
                    ForEach(overlaySettings.customCategories.indices, id: \.self) { index in
                        CategoryView(
                            category: $overlaySettings.customCategories[index],
                            selectedCategory: $selectedCategory,
                            showingSensorSelection: $showingSensorSelection,
                            categoryIndex: index,
                            totalCategories: overlaySettings.customCategories.count
                        )
                        .background(Color.clear) // Assicura che lo sfondo sia trasparente
                    }
                }
                .padding(.top, 5) // Aggiungi padding superiore se necessario
            }
            .background(Color.clear) // Rende trasparente lo sfondo dello ScrollView
        }
        .sheet(isPresented: $isPresentingNewCategorySheet) {
            NewCategorySheet(
                isPresented: $isPresentingNewCategorySheet,
                newCategoryName: $newCategoryName
            ) { name in
                // Crea e aggiungi la nuova categoria
                let newCategory = SensorCategory(name: name)
                overlaySettings.customCategories.append(newCategory)
                overlaySettings.saveOverlaySettings()
            }
        }
    }
}



// NewCategorySheet
struct NewCategorySheet: View {
    @Binding var isPresented: Bool
    @Binding var newCategoryName: String
    var onAdd: (String) -> Void

    var body: some View {
        VStack {
            Text("New Category")
                .font(.headline)
            TextField("Category Name", text: $newCategoryName)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
            HStack {
                Button("Cancel") {
                    isPresented = false
                }
                Spacer()
                Button("Add") {
                    if !newCategoryName.isEmpty {
                        onAdd(newCategoryName)
                        isPresented = false
                    }
                }
                .disabled(newCategoryName.isEmpty)
            }
            .padding()
        }
        .padding()
        .frame(width: 300)
    }
}

struct SensorButtonView: View {
    var sensor: AnySensor
    @State private var isEditing = false
    @EnvironmentObject var overlaySettings: OverlaySettings

    var body: some View {
        Button(action: {
            isEditing = true
        }) {
            HStack {
                VStack(alignment: .leading) {
                    Text(sensor.customDisplayName)
                        .font(.body)
                    Text(sensor.sensorKind.rawValue.capitalized) // Displays the sensor kind
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                Spacer()
                if sensor.isActive {
                    Image(systemName: "checkmark.circle.fill")
                        .foregroundColor(.green)
                } else {
                    Image(systemName: "circle")
                        .foregroundColor(.gray)
                }
            }
            .contentShape(Rectangle()) // Makes the entire row clickable
        }
        .buttonStyle(PlainButtonStyle()) // Removes the default button style
        .sheet(isPresented: $isEditing) {
            SensorConfigView(sensor: sensor)
                .environmentObject(overlaySettings) // Passes overlaySettings if needed
        }
    }
}


// CategoryView
// CategoryView
struct CategoryView: View {
    @Binding var category: SensorCategory
    @EnvironmentObject var overlaySettings: OverlaySettings
    @Binding var selectedCategory: SensorCategory?
    @Binding var showingSensorSelection: Bool

    var categoryIndex: Int
    var totalCategories: Int

    @State private var isPresentingCategoryConfig = false

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            // Nome della Categoria come Bottone con colore dinamico
            HStack {
                Button(action: {
                    isPresentingCategoryConfig = true
                }) {
                    Text(category.name)
                        .font(.headline)
                        .foregroundColor(.primary) // Utilizza colore dinamico adattato alla modalità
                }
                .buttonStyle(PlainButtonStyle()) // Rimuove lo stile predefinito del bottone

                Spacer()
                Button(action: {
                    // Elimina la categoria
                    if let index = overlaySettings.customCategories.firstIndex(where: { $0.id == category.id }) {
                        overlaySettings.customCategories.remove(at: index)
                        overlaySettings.saveOverlaySettings()
                    }
                }) {
                    Image(systemName: "trash")
                        .foregroundColor(.red)
                }
            }

            // Picker per lo stile di layout
            Picker(selection: $category.layoutStyle, label: EmptyView()) {
                ForEach(SensorLayoutStyle.allCases) { style in
                    Text(style.description).tag(style)
                }
            }
            .pickerStyle(SegmentedPickerStyle())
            .padding(.vertical, 5)

            // Visualizza Sensori con Opzioni di Riordinamento e Rimozione
            VStack(alignment: .leading) {
                Text("Sensors")
                    .font(.subheadline).bold()
                    .padding(.bottom, 5)

                ForEach(category.sensors) { sensor in
                    HStack {
                        SensorButtonView(sensor: sensor)
                        Spacer()
                        // Pulsanti per spostare il sensore su o giù e rimuoverlo
                        HStack(spacing: 10) {
                            Button(action: {
                                moveSensor(sensor, direction: .up)
                            }) {
                                Image(systemName: "chevron.up")
                            }
                            .disabled(isFirstSensor(sensor))

                            Button(action: {
                                moveSensor(sensor, direction: .down)
                            }) {
                                Image(systemName: "chevron.down")
                            }
                            .disabled(isLastSensor(sensor))

                            Button(action: {
                                removeSensor(sensor)
                            }) {
                                Image(systemName: "trash")
                                    .foregroundColor(.red)
                            }
                            .buttonStyle(PlainButtonStyle())
                        }
                    }
                    .padding(.vertical, 4)
                    .background(Color.clear) // Assicura che lo sfondo della riga sia trasparente
                }
            }

            // Bottoni per spostare la categoria e aggiungere sensori
            HStack {
                // Bottone Sposta Su
                Button(action: {
                    moveCategory(direction: .up)
                }) {
                    Image(systemName: "arrow.up")
                }
                .disabled(categoryIndex == 0) // Disabilita se è la prima categoria
                .padding(.trailing, 10)

                // Bottone Sposta Giù
                Button(action: {
                    moveCategory(direction: .down)
                }) {
                    Image(systemName: "arrow.down")
                }
                .disabled(categoryIndex == totalCategories - 1) // Disabilita se è l'ultima categoria
                .padding(.trailing, 10)

                Spacer()

                Button(action: {
                    selectedCategory = category
                    showingSensorSelection = true
                }) {
                    Label("Add Sensors", systemImage: "plus")
                }
            }
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(Color.gray.opacity(0.1)) // Mantiene lo sfondo se desiderato
                .shadow(color: Color.black.opacity(0.1), radius: 5, x: 0, y: 2)
        )
        .sheet(isPresented: $isPresentingCategoryConfig) {
            CategoryConfigView(category: $category)
                .environmentObject(overlaySettings)
        }
    }

    // MARK: - Funzioni Helper

    // Funzione per spostare un sensore
    private func moveSensor(_ sensor: AnySensor, direction: MoveDirection) {
        guard let currentIndex = category.sensors.firstIndex(where: { $0.id == sensor.id }) else { return }
        let newIndex: Int

        switch direction {
        case .up:
            newIndex = currentIndex - 1
            guard newIndex >= 0 else { return }
        case .down:
            newIndex = currentIndex + 1
            guard newIndex < category.sensors.count else { return }
        }

        category.sensors.move(fromOffsets: IndexSet(integer: currentIndex), toOffset: newIndex > currentIndex ? newIndex + 1 : newIndex)
        overlaySettings.saveOverlaySettings()
    }

    // Funzione per rimuovere un sensore
    private func removeSensor(_ sensor: AnySensor) {
        if let index = category.sensors.firstIndex(where: { $0.id == sensor.id }) {
            category.sensors.remove(at: index)
            overlaySettings.saveOverlaySettings()
        }
    }

    // Verifica se il sensore è il primo nella lista
    private func isFirstSensor(_ sensor: AnySensor) -> Bool {
        return category.sensors.first?.id == sensor.id
    }

    // Verifica se il sensore è l'ultimo nella lista
    private func isLastSensor(_ sensor: AnySensor) -> Bool {
        return category.sensors.last?.id == sensor.id
    }

    // Funzione per spostare la categoria nella direzione specificata
    private func moveCategory(direction: MoveDirection) {
        let currentIndex = categoryIndex
        var newIndex: Int

        switch direction {
        case .up:
            newIndex = currentIndex - 1
            guard newIndex >= 0 else { return }
        case .down:
            newIndex = currentIndex + 1
            guard newIndex < totalCategories else { return }
        }

        overlaySettings.customCategories.move(fromOffsets: IndexSet(integer: currentIndex), toOffset: newIndex > currentIndex ? newIndex + 1 : newIndex)
        overlaySettings.saveOverlaySettings()
    }

    // Enum per la direzione di spostamento
    private enum MoveDirection {
        case up
        case down
    }
}


struct CategoryConfigView: View {
    @Binding var category: SensorCategory
    @EnvironmentObject var overlaySettings: OverlaySettings
    @Environment(\.presentationMode) var presentationMode

    var body: some View {
        VStack(alignment: .leading) {
            Text("Edit Category")
                .font(.headline)
                .padding()

            TextField("Name", text: $category.name)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()

            // Aggiunta del ColorPicker per il colore del nome della categoria
            ColorPicker("Color", selection: $category.categoryNameColor)
                .padding()

            // Aggiunta del Toggle per mostrare/nascondere il nome della categoria
            Toggle("Show Category Name", isOn: $category.showCategoryName)
                .padding()

            Spacer()

            HStack {
                Spacer()
                Button("Cancel") {
                    presentationMode.wrappedValue.dismiss()
                }
                Button("Save") {
                    if !category.name.isEmpty {
                        overlaySettings.saveOverlaySettings()
                        presentationMode.wrappedValue.dismiss()
                    }
                }
                .disabled(category.name.isEmpty)
            }
            .padding()
        }
        .padding()
        .frame(width: 350, height: 300) // Aumentato l'altezza per accomodare i nuovi elementi
    }
}



// SensorConfigView
struct SensorConfigView: View {
    @ObservedObject var sensor: AnySensor
    @EnvironmentObject var overlaySettings: OverlaySettings
    @Environment(\.presentationMode) var presentationMode

    var body: some View {
        VStack(alignment: .leading) {
            HStack {
                Toggle("Show Name", isOn: $sensor.showName)
                Spacer()
                Toggle("Active", isOn: $sensor.isActive)
            }
            if sensor.showName {
                TextField("Display Name", text: $sensor.customDisplayName)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
            }
            HStack {
                ColorPicker("Name Color", selection: $sensor.nameColor)
                ColorPicker("Value Color", selection: $sensor.valueColor)
            }
            FontPicker(selectedFont: $sensor.font)
            Spacer()
            HStack {
                Spacer()
                Button("Done") {
                    presentationMode.wrappedValue.dismiss()
                }
                .padding()
            }
        }
        .padding()
        .frame(width: 400, height: 300)
        .onDisappear {
            overlaySettings.saveOverlaySettings()
        }
    }
}

struct SensorSelectionView: View {
    @EnvironmentObject var overlaySettings: OverlaySettings
    @ObservedObject var category: SensorCategory
    @Binding var isPresented: Bool

    @State private var selectedSensors: Set<UUID> = []
    @State private var searchText: String = ""

    var body: some View {
        VStack {
            Text("Select Sensors")
                .font(.headline)
                .padding()

            List {
                // Temperature Sensors Section
                sensorSection(title: "Temperature Sensors", sensors: sortedSensors(overlaySettings.allTemperatureSensors))

                // Voltage Sensors Section
                sensorSection(title: "Voltage Sensors", sensors: sortedSensors(overlaySettings.allVoltageSensors))

                // Current Sensors Section
                sensorSection(title: "Current Sensors", sensors: sortedSensors(overlaySettings.allCurrentSensors))

                // Power Sensors Section
                sensorSection(title: "Power Sensors", sensors: sortedSensors(overlaySettings.allPowerSensors))

                // Frequency Sensors Section
                sensorSection(title: "Frequency Sensors", sensors: sortedSensors(overlaySettings.allFrequencySensors))

                // Usage Sensors Section
                sensorSection(title: "Usage Sensors", sensors: sortedSensors(overlaySettings.allUsageSensors))

                // Fan Sensors Section
                sensorSection(title: "Fan Sensors", sensors: sortedSensors(overlaySettings.allFanSensors))
            }
            .listStyle(SidebarListStyle())
            .searchable(text: $searchText, placement: .automatic, prompt: "Search Sensors")
            // Alternative per macOS versions without .searchable:
            // .overlay(
            //     VStack {
            //         HStack {
            //             Image(systemName: "magnifyingglass")
            //             TextField("Search Sensors", text: $searchText)
            //                 .textFieldStyle(RoundedBorderTextFieldStyle())
            //         }
            //         .padding()
            //         Spacer()
            //     }
            // )
            
            HStack {
                Button("Cancel") {
                    isPresented = false
                }
                Spacer()
                Button("Add") {
                    addSelectedSensors()
                    isPresented = false
                }
                .disabled(selectedSensors.isEmpty)
            }
            .padding()
        }
        .frame(minWidth: 400, minHeight: 500) // Specifica le dimensioni minime
    }

    /// Helper function to sort sensors alphabetically and filter based on search text
    private func sortedSensors<S: SensorProtocol>(_ sensors: [S]) -> [S] {
        let filteredSensors: [S]
        if searchText.isEmpty {
            filteredSensors = sensors
        } else {
            filteredSensors = sensors.filter { $0.name.localizedCaseInsensitiveContains(searchText) }
        }
        return filteredSensors.sorted { $0.name.lowercased() < $1.name.lowercased() }
    }

    private func sensorSection<S: SensorProtocol>(title: String, sensors: [S]) -> some View {
        Section(header: Text(title)) {
            if sensors.isEmpty {
                Text("No sensors found.")
                    .foregroundColor(.secondary)
            } else {
                ForEach(sensors) { sensor in
                    let isSelected = selectedSensors.contains(sensor.id)
                    Button(action: {
                        if isSelected {
                            selectedSensors.remove(sensor.id)
                        } else {
                            selectedSensors.insert(sensor.id)
                        }
                    }) {
                        HStack {
                            Text(sensor.name)
                            Spacer()
                            if isSelected {
                                Image(systemName: "checkmark")
                                    .foregroundColor(.green)
                            }
                        }
                    }
                    .buttonStyle(PlainButtonStyle())
                }
            }
        }
    }

    private func addSelectedSensors() {
        // Raccogli tutti i sensori in un array
        let tempSensors = overlaySettings.allTemperatureSensors.map { $0 as any SensorProtocol }
        let voltageSensors = overlaySettings.allVoltageSensors.map { $0 as any SensorProtocol }
        let currentSensors = overlaySettings.allCurrentSensors.map { $0 as any SensorProtocol }
        let powerSensors = overlaySettings.allPowerSensors.map { $0 as any SensorProtocol }
        let frequencySensors = overlaySettings.allFrequencySensors.map { $0 as any SensorProtocol }
        let usageSensors = overlaySettings.allUsageSensors.map { $0 as any SensorProtocol }
        let fanSensors = overlaySettings.allFanSensors.map { $0 as any SensorProtocol }

        let allSensors = tempSensors + voltageSensors + currentSensors + powerSensors + frequencySensors + usageSensors + fanSensors

        let sensorsToAdd = allSensors.filter { selectedSensors.contains($0.id) }

        // Usa addSensor per garantire l'osservazione corretta
        for sensor in sensorsToAdd {
            if !category.sensors.contains(where: { $0.id == sensor.id }) {
                let anySensor = AnySensor(sensor)
                category.addSensor(anySensor)
            }
        }

        // Ordina i sensori della categoria dopo l'aggiunta
        category.sensors.sort { $0.customDisplayName.lowercased() < $1.customDisplayName.lowercased() }

        overlaySettings.saveOverlaySettings()
    }
}


// FontPicker View
struct FontPicker: View {
    @Binding var selectedFont: Font

    var body: some View {
        Picker("Font", selection: $selectedFont) {
            Text("Body").tag(Font.body)
            Text("Caption").tag(Font.caption)
            Text("Footnote").tag(Font.footnote)
            Text("Headline").tag(Font.headline)
            Text("Subheadline").tag(Font.subheadline)
            Text("Title").tag(Font.title)
            Text("Large Title").tag(Font.largeTitle)
        }
        .pickerStyle(MenuPickerStyle())
    }
}

struct OverlayView: View {
    @EnvironmentObject var overlaySettings: OverlaySettings

    var body: some View {
        VStack(alignment: .leading, spacing: 16 * overlaySettings.overlayScale) {
            ForEach(overlaySettings.customCategories) { category in
                if !category.sensors.filter({ $0.isActive }).isEmpty {
                    OverlayCategoryView(category: category, scale: overlaySettings.overlayScale)
                }
            }
        }
        .padding(16 * overlaySettings.overlayScale)
        .background(overlaySettings.overlayBackgroundColor.opacity(overlaySettings.overlayOpacity))
        .cornerRadius(overlaySettings.overlayCornerRadius * overlaySettings.overlayScale)
        .shadow(color: Color.black.opacity(0.1), radius: 4 * overlaySettings.overlayScale, x: 0, y: 2 * overlaySettings.overlayScale)
        .fixedSize() // Aggiungi questa linea per permettere al contenuto di espandersi
        .onAppear {
            overlaySettings.updateSelectedSensors()
        }
    }
}








struct OverlayCategoryView: View {
    @ObservedObject var category: SensorCategory
    var scale: CGFloat

    var body: some View {
        VStack(alignment: .leading, spacing: 8 * scale) {
            if category.showCategoryName {
                Text(category.name)
                    .font(.headline)
                    .foregroundColor(.primary)
            }
            let activeSensors = category.sensors.filter { $0.isActive }
            if !activeSensors.isEmpty {
                if category.layoutStyle == .singleLine {
                    HStack(spacing: 8 * scale) {
                        ForEach(activeSensors) { sensor in
                            OverlaySensorView(sensor: sensor, scale: scale)
                        }
                    }
                    .fixedSize() // Aggiungi questa linea per permettere all'HStack di espandersi
                } else {
                    VStack(alignment: .leading, spacing: 8 * scale) {
                        ForEach(activeSensors) { sensor in
                            OverlaySensorView(sensor: sensor, scale: scale)
                        }
                    }
                }
            }
        }
    }
}




// OverlaySensorGridView
struct OverlaySensorGridView: View {
    var sensors: [AnySensor]
    let columns: [GridItem]
    var scale: CGFloat

    init(sensors: [AnySensor], scale: CGFloat) {
        self.sensors = sensors
        self.scale = scale
        let columnCount = 5 // Adjust as needed
        self.columns = Array(repeating: .init(.flexible()), count: columnCount)
    }

    var body: some View {
        LazyVGrid(columns: columns, spacing: 16 * scale) {
            ForEach(sensors) { sensor in
                OverlaySensorView(sensor: sensor, scale: scale)
            }
        }
    }
}


// OverlaySensorView
struct OverlaySensorView: View {
    @ObservedObject var sensor: AnySensor
        var scale: CGFloat

        var body: some View {
            if sensor.showName {
                Text("\(sensor.customDisplayName): \(formattedDisplayValue(for: sensor))")
                    .foregroundColor(sensor.nameColor)
                    .font(adjustedFont(font: sensor.font, scale: scale))
                    .fixedSize(horizontal: true, vertical: false) // Aggiungi questa linea
            } else {
                Text(formattedDisplayValue(for: sensor))
                    .foregroundColor(sensor.valueColor)
                    .font(adjustedFont(font: sensor.font, scale: scale))
                    .fixedSize(horizontal: true, vertical: false) // Aggiungi questa linea
            }
        }

    /// Helper function to adjust the font size based on the scale
    private func adjustedFont(font: Font, scale: CGFloat) -> Font {
        // Define base sizes for different fonts
        let baseSize: CGFloat
        let weight: Font.Weight

        switch font {
        case .largeTitle:
            baseSize = 34
            weight = .regular
        case .title:
            baseSize = 28
            weight = .regular
        case .title2:
            baseSize = 22
            weight = .regular
        case .title3:
            baseSize = 20
            weight = .regular
        case .headline:
            baseSize = 17
            weight = .semibold
        case .body:
            baseSize = 17
            weight = .regular
        case .callout:
            baseSize = 16
            weight = .regular
        case .subheadline:
            baseSize = 15
            weight = .regular
        case .footnote:
            baseSize = 13
            weight = .regular
        case .caption:
            baseSize = 12
            weight = .regular
        case .caption2:
            baseSize = 11
            weight = .regular
        default:
            baseSize = 17
            weight = .regular
        }

        return .system(size: baseSize * scale, weight: weight)
    }

    private func formattedDisplayValue(for sensor: AnySensor) -> String {
        switch sensor.sensorKind {
        case .memory:
            return sensor.displayValue // Formattato in MB
        case .usage:
            return sensor.displayValue // Formattato in %
        default:
            return sensor.displayValue
        }
    }

}




