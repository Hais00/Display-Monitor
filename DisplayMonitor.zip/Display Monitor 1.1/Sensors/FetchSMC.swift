import SwiftUI



final class SMCSensors: ObservableObject {
    @Published var temperatureSensors: [TemperatureSensor] = []
    @Published var voltageSensors: [VoltageSensor] = []
    @Published var currentSensors: [CurrentSensor] = []
    @Published var powerSensors: [PowerSensor] = []
    @Published var fanSensors: [FanSensor] = []

    @Published var selectedVoltageUnit: VoltageUnit = .mV
    @Published var selectedCurrentUnit: CurrentUnit = .mA
}
