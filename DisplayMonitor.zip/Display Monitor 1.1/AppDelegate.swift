//
//  AppDelegate.swift
//  Display Monitor 1.1
//
//  Created by Jason Polizzi on 04/11/24.
//

import Cocoa
import ApplicationServices
import Security
import Foundation
import MachO // Per i tipi di dati utilizzati
import Darwin // Fornisce `mach_host_self`
import SwiftUI
import IOKit
import Combine
import HotKey
import ServiceManagement




@objc extension AppDelegate {
    func handleToggleMetalHUD(_ notification: Notification) {
        if let isActive = notification.object as? Bool {
            toggleMetalHUD(isActive)
        }
    }
}

var hotKey: HotKey?
class AppDelegate: NSObject, NSApplicationDelegate {
    var hidSensors = HIDSensors()
    var hidController: HIDController?
    var smcSensors = SMCSensors()
    var smcController: SMCController?
    var powermetricsSensors = PowermetricsSensors()
    var powermetricsController: PowermetricsController?
    var sensorsWindowController: SensorsWindowController?
    var settingsWindowController: SettingsWindowController?
    var initialMetalHUDActive: Bool = false

    var smcUpdateTimer: Timer?
    var isCoreCacheInitialized: Bool = false
    
    var window: NSWindow!
    var statusItem: NSStatusItem!
    var isHookSetUp = false
    var eCoreLabels: [NSTextField] = []
    var pCoreLabels: [NSTextField] = []
    var gpuFrequencyLabel: NSTextField!
    var gpuUsageLabel: NSTextField!
    var gpuPowerLabel: NSTextField!
    var cpuPowerLabel: NSTextField!
    var socLabel: NSTextField!
    var gpuTemperatureLabel: NSTextField!
    var memoryUsageLabel: NSTextField!
    var activeWindowTimer: Timer?
    var userPassword: String?
    var lastActiveAppPID: pid_t?
    var cancellables = Set<AnyCancellable>()
    let HOST_VM_INFO64_COUNT = UInt32(MemoryLayout<vm_statistics64_data_t>.size / MemoryLayout<integer_t>.size)
    
    // Sottoview per E-Cores e P-Cores
    var eCoreStackView: NSStackView!
    var pCoreStackView: NSStackView!
    
    // Variabili di stato per Overlay e Metal HUD
    var isMetalHUDActive: Bool = true

    // Flag per assicurare un solo thread di lettura
    var isReading: Bool = false
    func getChipName() -> String? {
        var size = 0
        sysctlbyname("machdep.cpu.brand_string", nil, &size, nil, 0)
        var cpuName = [CChar](repeating: 0, count: size)
        sysctlbyname("machdep.cpu.brand_string", &cpuName, &size, nil, 0)
        return String(cString: cpuName)
    }

    func startMonitoringActiveWindow() {
        activeWindowTimer = Timer.scheduledTimer(withTimeInterval: 2.0, repeats: true) { [weak self] _ in
            self?.analyzeActiveWindow()
        }
    }
    
    func stopMonitoringActiveWindow() {
        activeWindowTimer?.invalidate()
        activeWindowTimer = nil
        //fpsTimer?.invalidate()
        //fpsTimer = nil
    }

    func memoryUsage(existingSensors: inout [UsageSensor]) {
        var totalMemory: UInt64 = 0
        var freeMemory: UInt64 = 0
        var usedMemory: UInt64 = 0
        var activeMemory: UInt64 = 0
        var inactiveMemory: UInt64 = 0
        var wiredMemory: UInt64 = 0
        var compressedMemory: UInt64 = 0
        
        var size = MemoryLayout<UInt64>.size
        var totalSize: UInt64 = 0
        if sysctlbyname("hw.memsize", &totalSize, &size, nil, 0) != 0 {
            return
        }
        totalMemory = totalSize
        
        var stats = vm_statistics64()
        var count = HOST_VM_INFO64_COUNT
        let hostPort = mach_host_self()
        
        let result = withUnsafeMutablePointer(to: &stats) {
            $0.withMemoryRebound(to: integer_t.self, capacity: Int(count)) {
                host_statistics64(hostPort, HOST_VM_INFO64, $0, &count)
            }
        }
        
        guard result == KERN_SUCCESS else {
            return
        }
        
        let pageSize: UInt64 = 16384
        activeMemory = UInt64(stats.active_count) * pageSize
        inactiveMemory = UInt64(stats.inactive_count) * pageSize
        wiredMemory = UInt64(stats.wire_count) * pageSize
        compressedMemory = UInt64(stats.compressor_page_count) * pageSize
        freeMemory = (UInt64(stats.free_count) + UInt64(stats.inactive_count)) * pageSize
        usedMemory = activeMemory + wiredMemory + compressedMemory
        
        // Converti i valori in MB per la visualizzazione
        let totalMemoryMB = Double(totalMemory) / (1024.0 * 1024.0)
        let usedMemoryMB = Double(usedMemory) / (1024.0 * 1024.0)
        let freeMemoryMB = Double(freeMemory) / (1024.0 * 1024.0)
        let activeMemoryMB = Double(activeMemory) / (1024.0 * 1024.0)
        let inactiveMemoryMB = Double(inactiveMemory) / (1024.0 * 1024.0)
        let wiredMemoryMB = Double(wiredMemory) / (1024.0 * 1024.0)
        let compressedMemoryMB = Double(compressedMemory) / (1024.0 * 1024.0)
        
        // Creiamo un array di nuovi sensori di memoria
        let newSensors: [UsageSensor] = [
                MemorySensor(name: "Total Memory", value: totalMemoryMB),
                MemorySensor(name: "Used Memory", value: usedMemoryMB),
                MemorySensor(name: "Free Memory", value: freeMemoryMB),
                MemorySensor(name: "Active Memory", value: activeMemoryMB),
                MemorySensor(name: "Inactive Memory", value: inactiveMemoryMB),
                MemorySensor(name: "Wired Memory", value: wiredMemoryMB),
                MemorySensor(name: "Compressed Memory", value: compressedMemoryMB)
            ]

            // Aggiorniamo l'array esistente con i nuovi sensori
            updateSensors(existingSensors: &existingSensors, newSensorData: newSensors)
    }






    func updateSensors(existingSensors: inout [UsageSensor], newSensorData: [UsageSensor]) {
        for newSensor in newSensorData {
            if let index = existingSensors.firstIndex(where: { $0.name == newSensor.name }) {
                existingSensors[index].value = newSensor.value
            } else {
                existingSensors.append(newSensor)
            }
        }

    }

    private var timer: Timer?
    private func startTimer() {
        timer = Timer.scheduledTimer(withTimeInterval: 2.0, repeats: true) { [weak self] _ in
            guard let self = self else { return }
            DispatchQueue.global(qos: .background).async {
                // Chiama memoryUsage per aggiornare usageData
                self.memoryUsage(existingSensors: &self.powermetricsSensors.usageData)
            }
        }
    }

    lazy var overlaySettings: OverlaySettings = {
        let settings = OverlaySettings(
            hidSensors: hidSensors,
            powermetricsSensors: powermetricsSensors,
            smcSensors: smcSensors
        )
        // Inizializza `SMC` con `overlaySettings` dopo averlo creato
        SMC.initialize(overlaySettings: settings)
        return settings
    }()


    func checkAndProceedWithSensorsData(
        hidSensors: HIDSensors,
        powermetricsSensors: PowermetricsSensors,
        smcSensors: SMCSensors,
        overlaySettings: OverlaySettings,
        maxRetries: Int = 45,
        retryInterval: TimeInterval = 2.0
    ) {
        var retryCount = 0
        var timerStarted = false

        func necessarySensorsPopulated() -> Bool {
            // Avvia il timer solo una volta
            if !timerStarted {
                startTimer()
                timerStarted = true
            }

            // Popola i dati di utilizzo della memoria
            memoryUsage(existingSensors: &powermetricsSensors.usageData)

            // Verifica che tutti i sensori essenziali siano presenti
            let requiredMemorySensors = [
                "Total Memory", "Used Memory", "Free Memory",
                "Active Memory", "Inactive Memory", "Wired Memory", "Compressed Memory"
            ]

            // Controlla la presenza di ciascun sensore di memoria
            let memorySensorsPopulated = requiredMemorySensors.allSatisfy { name in
                powermetricsSensors.usageData.contains { $0.name == name }
            }

            // Verifica anche gli altri sensori (HID, SMC, e powermetrics)
            var required = memorySensorsPopulated &&
                           !hidSensors.temperatureSensors.isEmpty &&
                           !powermetricsSensors.frequencyData.isEmpty &&
                           !powermetricsSensors.powerData.isEmpty &&
                           !smcSensors.temperatureSensors.isEmpty &&
                           !smcSensors.voltageSensors.isEmpty &&
                           !smcSensors.currentSensors.isEmpty &&
                           !smcSensors.powerSensors.isEmpty

            // Se showUnknownSensors è attivo, verifica anche i sensori opzionali
            if overlaySettings.showUnknownSensors {
                required = required &&
                           !hidSensors.voltageSensors.isEmpty &&
                           !hidSensors.currentSensors.isEmpty
            }

            return required
        }

        func checkAndProceed() {
            // Popolazione dei dati di memoria e verifica
            memoryUsage(existingSensors: &powermetricsSensors.usageData)

            if necessarySensorsPopulated() {
                print("Debug: Tutti gli array necessari dei sensori sono popolati. Procedo con l'inizializzazione dell'overlay.")

                // Esegui le funzioni successive
                overlaySettings.loadLayout()
                overlaySettings.loadOverlaySettings()
                overlaySettings.setupSensorObservers()
                overlaySettings.setupCategoriesObserver()
                overlaySettings.setOff()
                overlaySettings.refreshOverlay()

                hotKey = HotKey(key: .o, modifiers: [.command, .shift])
                hotKey?.keyDownHandler = { [weak self] in
                    self?.toggleOverlay()
                }

            } else if retryCount < maxRetries {
                retryCount += 1
                print("Debug: Alcuni array dei sensori non sono ancora popolati. Tentativo \(retryCount) di \(maxRetries).")

                // Ritenta dopo un intervallo
                DispatchQueue.global().asyncAfter(deadline: .now() + retryInterval) {
                    checkAndProceed()
                }
            } else {
                print("Errore: Gli array dei sensori non sono stati popolati entro il limite massimo di tentativi.")
            }
        }

        // Avvia il primo controllo
        checkAndProceed()
    }


    func installHelper() {
        let helperLabel = "displaymonitor.DisplayMonitor.Helper" as CFString
        
        // Controlla se l'helper è già installato nel dominio di sistema
        if SMJobCopyDictionary(kSMDomainSystemLaunchd, helperLabel) != nil {
            print("L'helper è già installato.")
            return
        }
        
        var authRef: AuthorizationRef?
        var authStatus = AuthorizationCreate(nil, nil, [.preAuthorize], &authRef)
        
        guard authStatus == errAuthorizationSuccess else {
            print("Impossibile ottenere un riferimento di autorizzazione valido per caricare il daemon Helper")
            return
        }
        
        let authItem = kSMRightBlessPrivilegedHelper.withCString { authorizationString in
            AuthorizationItem(name: authorizationString, valueLength: 0, value: nil, flags: 0)
        }
        
        let pointer = UnsafeMutablePointer<AuthorizationItem>.allocate(capacity: 1)
        pointer.initialize(to: authItem)
        
        defer {
            pointer.deinitialize(count: 1)
            pointer.deallocate()
        }
        
        var authRights = AuthorizationRights(count: 1, items: pointer)
        
        let flags: AuthorizationFlags = [.interactionAllowed, .extendRights, .preAuthorize]
        authStatus = AuthorizationCreate(&authRights, nil, flags, &authRef)
        
        guard authStatus == errAuthorizationSuccess else {
            print("Impossibile ottenere un riferimento di autorizzazione valido per caricare il daemon Helper")
            return
        }
        
        var error: Unmanaged<CFError>?
        if SMJobBless(kSMDomainSystemLaunchd, helperLabel, authRef, &error) == false {
            if let blessError = error?.takeRetainedValue() {
                let domain = CFErrorGetDomain(blessError) as String
                let code = CFErrorGetCode(blessError)
                let description = CFErrorCopyDescription(blessError) as String? ?? "Nessuna descrizione"
                
                print("Dominio errore: \(domain)")
                print("Codice errore: \(code)")
                print("Descrizione errore: \(description)")
                
                if code == Int(kSMErrorInternalFailure) {
                    print("Incontrato kSMErrorInternalFailure")
                }
            }
            return
        }
        
        AuthorizationFree(authRef!, [])
        print("Helper installato con successo!")
    }



    func applicationDidFinishLaunching(_ notification: Notification) {
            checkAccessibilityPermissions()
            guard AXIsProcessTrusted() else {
                return
            }

            // Richiedi la password dell'utente solo se necessario
            if let password = requestPassword() {
                userPassword = password
                
                // Variabile globale per memorizzare il nome del chip
                let chipName: String? = getChipName()

                // Stampa il nome del chip
                if let name = chipName {
                    print("Chip Name: \(name)")
                } else {
                    print("Chip name could not be retrieved.")
                }
                NotificationCenter.default.addObserver(self, selector: #selector(handleToggleMetalHUD(_:)), name: .toggleMetalHUD, object: nil)
                powermetricsController = PowermetricsController(powermetricsSensors: powermetricsSensors, userPassword: userPassword)
                powermetricsController?.startPowermetrics()
                
                // Inizializza i controller dei sensori
                smcController = SMCController(smcSensors: smcSensors)
                smcController?.startSMCUpdateTimer()
                
                hidController = HIDController(hidSensors: hidSensors, overlaySettings: overlaySettings)
                hidController?.startHIDUpdateTimer()
                
                
                checkAndProceedWithSensorsData(
                hidSensors: hidSensors,
                powermetricsSensors: powermetricsSensors,
                smcSensors: smcSensors,
                overlaySettings: overlaySettings
                )
                    
                if overlaySettings.isOverlayActive {
                            HUDWindow.createHUDWindows(overlaySettings: overlaySettings)
                            print("Debug: HUD attivato all'avvio perché isOverlayActive è true")
                        }  

                // Osserva i cambiamenti di isOverlayActive per gestire l'HUD in tempo reale
                overlaySettings.$isOverlayActive
                    .receive(on: DispatchQueue.main)
                    .sink { [weak self] isActive in
                        if isActive {
                            HUDWindow.createHUDWindows(overlaySettings: self?.overlaySettings ?? OverlaySettings(hidSensors: HIDSensors(), powermetricsSensors: PowermetricsSensors(), smcSensors: SMCSensors()))
                            print("Debug: HUD attivato tramite isOverlayActive")
                        } else {
                            HUDWindow.closeAllHUDWindows()
                            print("Debug: HUD disattivato tramite isOverlayActive")
                        }
                    }
                    .store(in: &cancellables)
                setupStatusBarItem()
                observeMenuStateChanges()
                
                initialMetalHUDActive = overlaySettings.isMetalHUDActive
                            if initialMetalHUDActive {
                                toggleMetalHUD(true)
                                print("Debug: Metal HUD attivato all'avvio perché isMetalHUDActive è true")
                            } else {
                                print("Debug: Metal HUD non attivato all'avvio perché isMetalHUDActive è false")
                            }
            }
            
            // Avvia il monitoraggio della finestra attiva
            startMonitoringActiveWindow()
            

        }

    @objc func showSensorsWindow() {
        if sensorsWindowController == nil {
            sensorsWindowController = SensorsWindowController(
                hidSensors: self.hidSensors,
                smcSensors: self.smcSensors,
                powermetricsSensors: self.powermetricsSensors,
                overlaySettings: self.overlaySettings
            )
        }
        sensorsWindowController?.showWindow(nil)
        NSApp.activate(ignoringOtherApps: true) // Porta l'app in primo piano se necessario
    }

    func updateHUD() {
        guard overlaySettings.isOverlayActive else { return }
        // SwiftUI aggiornerà automaticamente la vista con i nuovi dati nei sensori.
    }


    func updateOverlayMenuItemState() {
            if let menu = statusItem.menu,
               let overlayMenuItem = menu.item(withTitle: "Overlay") {
                overlayMenuItem.state = overlaySettings.isOverlayActive ? .on : .off
            }
        }



 
    
    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool {
        return false
    }
    
    
    func applicationWillTerminate(_ notification: Notification) {
        powermetricsController?.stopPowermetrics()
        toggleMetalHUD(false)
        stopMonitoringActiveWindow()
        smcController?.stopSMCUpdateTimer()
        hidController?.stopHIDUpdateTimer()
        if initialMetalHUDActive {
                    toggleMetalHUD(false)
                    print("Debug: Metal HUD disattivato alla chiusura perché era attivo all'avvio")
                } else {
                    print("Debug: Metal HUD non disattivato alla chiusura perché era già inattivo all'avvio")
                }
    }
    
    // MARK: - Configurazione della Barra dei Menu
    func setupStatusBarItem() {
            statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)

            if let button = statusItem.button {
            if let resizedImage = NSImage(named: "AppIcon") {
                resizedImage.size = NSSize(width: 20, height: 20)
                button.image = resizedImage
                button.image?.isTemplate = false
            } else {
                print("Immagine AppIcon non trovata. Assicurati che sia inclusa nel progetto.")
                button.title = "❓" // Mostra un'icona di fallback
                }
            }


            let menu = NSMenu()

            menu.addItem(NSMenuItem(title: "Settings", action: #selector(showSettingsWindow), keyEquivalent: "S"))
            menu.addItem(NSMenuItem.separator())
            menu.addItem(NSMenuItem(title: "Quit", action: #selector(quitApp), keyEquivalent: "q"))

            statusItem.menu = menu
        }
    


    func observeMenuStateChanges() {
            // Sincronizza solo lo stato del menu con `isOverlayActive`
            overlaySettings.$isOverlayActive
                .sink { [weak self] _ in
                    self?.updateOverlayMenuItemState()
                }
                .store(in: &cancellables)
        }

    @objc func showSettingsWindow() {
        if settingsWindowController == nil {
            settingsWindowController = SettingsWindowController(overlaySettings: overlaySettings)
        }
        settingsWindowController?.showWindow(nil)
        NSApp.activate(ignoringOtherApps: true)
    }



    func saveHotkey(keyCode: UInt32, modifiers: UInt32) {
        UserDefaults.standard.set(keyCode, forKey: "OverlayHotKeyCode")
        UserDefaults.standard.set(modifiers, forKey: "OverlayHotKeyModifiers")
    }

    func loadHotkey() -> (UInt32, UInt32)? {
        guard let keyCode = UserDefaults.standard.value(forKey: "OverlayHotKeyCode") as? UInt32,
              let modifiers = UserDefaults.standard.value(forKey: "OverlayHotKeyModifiers") as? UInt32 else {
            return nil
        }
        return (keyCode, modifiers)
    }







    // Rappresenta la riga di selezione del sensore
    struct SensorSelectionRow: View {
        let sensorName: String
        @Binding var selectedSensors: [String]
        
        var body: some View {
            Toggle(sensorName, isOn: Binding(
                get: { selectedSensors.contains(sensorName) },
                set: { isSelected in
                    if isSelected {
                        selectedSensors.append(sensorName)
                    } else {
                        selectedSensors.removeAll { $0 == sensorName }
                    }
                }
            ))
        }
    }
    
    
    
    
    @objc func openSettings() {
        if settingsWindowController == nil {
            settingsWindowController = SettingsWindowController(coder: NSCoder())

        }
        settingsWindowController?.showWindow(nil)
    }
    
    @objc func toggleOverlay() {
            // Cambia solo lo stato di `isOverlayActive`, il `sink` farà il resto
            overlaySettings.isOverlayActive.toggle()
        }


    @objc func toggleOverlayMenuItem() {
        // Cambia lo stato di `isOverlayActive` e aggiorna il menu
        overlaySettings.isOverlayActive.toggle()
        updateOverlayMenuItemState()
        // Rimuovi la chiamata a toggleOverlay()
        // toggleOverlay()
    }



    
    @objc func toggleMetalHUDMenu(_ sender: NSMenuItem? = nil) {
        isMetalHUDActive.toggle()
        toggleMetalHUD(isMetalHUDActive)
        
        // Aggiorna lo stato del menu
        sender?.state = isMetalHUDActive ? .on : .off
    }

    
    @objc func quitApp() {
        NSApp.terminate(nil)
    }
    
    func isAppSandboxed() -> Bool {
        return ProcessInfo.processInfo.environment["APP_SANDBOX_CONTAINER_ID"] != nil
    }
    
    // MARK: - Gestione Permessi di Accessibilità
    func checkAccessibilityPermissions() {
        let options: NSDictionary = [kAXTrustedCheckOptionPrompt.takeUnretainedValue() as String: true]
        let accessEnabled = AXIsProcessTrustedWithOptions(options)
        
        if accessEnabled {
        
        } else {
            showAccessibilityAlert()
        }
    }
    
    func showAccessibilityAlert() {
        let alert = NSAlert()
        alert.messageText = "Accessibility Permissions Required"
        alert.informativeText = """
        To function properly, this application requires Accessibility permissions.
        Please go to System Preferences > Security & Privacy > Privacy > Accessibility, 
        and enable permissions for this application. After granting the permissions, 
        please restart the application.
        """
        alert.alertStyle = .warning
        alert.addButton(withTitle: "Open System Preferences")
        alert.addButton(withTitle: "Quit")
        
        // Mostra l'alert e gestisci la risposta
        let response = alert.runModal()
        if response == .alertFirstButtonReturn {
            // Apre le Preferenze di Sistema alla sezione di Accessibilità
            if let url = URL(string: "x-apple.systempreferences:com.apple.preference.security?Privacy_Accessibility") {
                NSWorkspace.shared.open(url)
            }
        }
        
        NSApp.terminate(nil)
    }
    
    
    func calculateMaxWidth(stackView: NSStackView) -> CGFloat {
        var maxWidth: CGFloat = 0.0
        for subview in stackView.arrangedSubviews {
            if let label = subview as? NSTextField {
                let fittingSize = label.sizeThatFits(NSSize(width: CGFloat.greatestFiniteMagnitude, height: label.frame.height))
                maxWidth = max(maxWidth, fittingSize.width)
            }
        }
        return maxWidth
    }
    
    func analyzeActiveWindow() {
        guard let activeApp = NSWorkspace.shared.frontmostApplication else {
            print("Nessuna applicazione attiva trovata.")
            return
        }
        
        let appPID = activeApp.processIdentifier
        // Verifica se l'app attiva è cambiata
        if appPID == lastActiveAppPID {
            return
        }
        
        lastActiveAppPID = appPID
        let usesOpenGL = isUsingOpenGL(pid: appPID)
        
        if usesOpenGL {
            print("Applicazione usa OpenGL. Calcolo degli FPS in corso.")
            // Implementa la logica per calcolare gli FPS
        }
        
        else {
            print("Applicazione non usa OpenGL.")
        }
    }
    
    
    
    func isUsingOpenGL(pid: pid_t) -> Bool {
        let task = Process()
        task.launchPath = "/usr/sbin/lsof"
        task.arguments = ["-p", "\(pid)"]
        
        let pipe = Pipe()
        task.standardOutput = pipe
        task.launch()
        
        let outputData = pipe.fileHandleForReading.readDataToEndOfFile()
        guard let output = String(data: outputData, encoding: .utf8) else { return false }
        
        return output.contains("libGL") || output.contains("OpenGL")
    }
    
    func updateWindowSize(hudWindow: HUDWindow, stackView: NSStackView) {
        DispatchQueue.main.async {
            let maxTextWidth = self.calculateMaxWidth(stackView: stackView)
            let fittingHeight = stackView.fittingSize.height
            let newWidth = maxTextWidth + 20
            let newHeight = max(fittingHeight + 20, 100)
            
            hudWindow.setContentSize(NSSize(width: newWidth, height: newHeight))
            hudWindow.layoutIfNeeded() // Assicura che il layout venga aggiornato immediatamente
        }
    }

    
    
    
    
    
    func getSSDModel() -> String? {
        let matchingDict = IOServiceMatching("IOBlockStorageDevice")
        var iterator: io_iterator_t = 0
        defer { IOObjectRelease(iterator) }
        
        guard IOServiceGetMatchingServices(kIOMasterPortDefault, matchingDict, &iterator) == KERN_SUCCESS else {
            return nil
        }
        
        while case let service = IOIteratorNext(iterator), service != 0 {
            defer { IOObjectRelease(service) }
            
            if let modelData = IORegistryEntryCreateCFProperty(service, "Model" as CFString, kCFAllocatorDefault, 0)?.takeRetainedValue() as? String {
                return modelData
            }
        }
        return nil
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    var fileMonitorSource: DispatchSourceFileSystemObject?
    
    
    
    
    
    
    // Funzioni di supporto per ottenere i nomi e i valori dei sensori di corrente
    func getCurrentSensorNames() -> [String]? {
        guard let currentSensors = matching(0xff08, 2)?.takeRetainedValue() as? [CFString] else {
            print("Errore nel recuperare i nomi dei sensori di corrente.")
            return nil
        }
        return currentSensors.map { $0 as String }
    }
    
    // MARK: - Gestione Powermetrics
    func toggleMetalHUD(_ enabled: Bool) {
            let command = enabled ? "/bin/launchctl setenv MTL_HUD_ENABLED 1" : "/bin/launchctl setenv MTL_HUD_ENABLED 0"

            let process = Process()
            process.launchPath = "/bin/bash"
            process.arguments = ["-c", command]

            do {
                try process.run()
                process.waitUntilExit()
            } catch {
                // print("Errore durante l'esecuzione del comando: \(error)") // Debug print commentato
            }
        }
    
    
    // Richiede la password una sola volta all'avvio
    func requestPassword() -> String? {
        let alert = NSAlert()
        alert.messageText = "Administrator Privileges Required"
        alert.informativeText = "Please enter your password to allow powermetrics to run with sudo."
        alert.alertStyle = .warning
        alert.addButton(withTitle: "OK")
        alert.addButton(withTitle: "Cancel")
        
        let passwordField = NSSecureTextField(frame: NSRect(x: 0, y: 0, width: 200, height: 24))
        alert.accessoryView = passwordField
        
        let response = alert.runModal()
        if response == .alertFirstButtonReturn {
            return passwordField.stringValue
        }
        return nil
    }
    
    // Avvia powermetrics con sudo e configurazione di DispatchSource per leggere i dati
    
    
    func monitorFile(at url: URL) {
        // Apri il file in sola lettura
        let fileDescriptor = open(url.path, O_EVTONLY)
        
        // Verifica che il file sia stato aperto correttamente
        guard fileDescriptor != -1 else {
            print("Impossibile aprire il file")
            return
        }
        
        // Crea un `DispatchSource` per monitorare le modifiche al file
        fileMonitorSource = DispatchSource.makeFileSystemObjectSource(
            fileDescriptor: fileDescriptor,
            eventMask: .write,
            queue: DispatchQueue.global(qos: .background) // Esegui il monitoraggio in background
        )
        
        // Definisce cosa fare quando ci sono modifiche al file
        fileMonitorSource?.setEventHandler { [weak self] in
            guard let self = self else { return }
            
            // Esegui azioni alternative al posto di `readNewData`
            print("Il file è stato modificato a \(url.path)")
            
            // Inserisci qui altre azioni che vuoi eseguire quando il file viene modificato
            self.handleFileChange()
        }
        
        // Definisce cosa fare quando il monitor viene cancellato
        fileMonitorSource?.setCancelHandler {
            close(fileDescriptor)
        }
        
        // Avvia il monitoraggio del file
        fileMonitorSource?.resume()
    }
    
    // Funzione di esempio per gestire le modifiche del file
    func handleFileChange() {
        // Qui puoi inserire qualsiasi logica di aggiornamento o di notifica
        print("Gestione della modifica del file eseguita.")
    }
    
    
    
        
    func removeAppFiles() {
            guard let username = getCurrentUsername() else {
                // print("Unable to retrieve the current username.") // Debug print commentato
                return
            }
            
            let appDirectory = URL(fileURLWithPath: "/Users/\(username)/Documents/Cartella")
            let scriptPath = appDirectory.appendingPathComponent("run_powermetrics.sh")
            let outputPath = appDirectory.appendingPathComponent("powermetrics_output.txt")
            
            do {
                try FileManager.default.removeItem(at: scriptPath)
                try FileManager.default.removeItem(at: outputPath)
                try FileManager.default.removeItem(at: appDirectory)
                // print("App directory and files removed from documents directory.") // Debug print commentato
            } catch {
                // print("Failed to remove files or directory from documents directory. Error: \(error)") // Debug print commentato
            }
    }
}
   
extension String {
    var fourCharCode: OSType {
        var result: OSType = 0
        for char in utf8 {
            result = (result << 8) + OSType(char)
        }
        return result
    }
}
