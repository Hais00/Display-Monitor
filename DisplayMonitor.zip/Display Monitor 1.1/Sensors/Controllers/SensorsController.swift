import SwiftUI

class SensorsWindowController: NSWindowController {
    var hidSensors: HIDSensors
    var smcSensors: SMCSensors
    var powermetricsSensors: PowermetricsSensors
    var overlaySettings: OverlaySettings
    
    init(hidSensors: HIDSensors, smcSensors: SMCSensors, powermetricsSensors: PowermetricsSensors, overlaySettings: OverlaySettings) {
        self.hidSensors = hidSensors
        self.smcSensors = smcSensors
        self.powermetricsSensors = powermetricsSensors
        self.overlaySettings = overlaySettings
        super.init(window: nil)
        setupWindow()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupWindow() {
        // Creazione della vista SwiftUI e iniezione degli environment objects
        let sensorsView = SensorsView()
            .environmentObject(self.overlaySettings)
            .environmentObject(self.hidSensors)
            .environmentObject(self.smcSensors)
            .environmentObject(self.powermetricsSensors)
        
        let hostingController = NSHostingController(rootView: sensorsView)
        
        // Configurazione della finestra
        let window = NSWindow(
            contentRect: NSRect(x: 0, y: 0, width: 800, height: 600),
            styleMask: [.titled, .closable, .resizable],
            backing: .buffered,
            defer: false
        )
        window.title = "Sensors"
        window.center()
        window.contentView = hostingController.view
        self.window = window
        self.window?.makeKeyAndOrderFront(nil)
    }
}
