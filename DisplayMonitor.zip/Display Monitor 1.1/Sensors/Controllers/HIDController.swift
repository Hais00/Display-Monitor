import SwiftUI
import Combine

class HIDController {
    var hidSensors: HIDSensors
    var hidUpdateTimer: Timer?
    private var overlaySettings: OverlaySettings
    private var cancellables = Set<AnyCancellable>()

    init(hidSensors: HIDSensors, overlaySettings: OverlaySettings) {
        self.hidSensors = hidSensors
        self.overlaySettings = overlaySettings

        // Osserva i cambiamenti di showUnknownSensors
        overlaySettings.$showUnknownSensors
            .sink { [weak self] _ in
                Task {
                    await self?.updateHIDSensors()
                }
            }
            .store(in: &cancellables)
    }

    // MARK: - Fetching Sensor Data
    func fetchHIDVoltageSensorData() -> [VoltageSensor] {
        var voltageSensors: [VoltageSensor] = []

        guard let voltageSensorsDict = matching(0xff08, 3)?.takeRetainedValue() as CFDictionary? else {
            print("Errore nel recuperare i sensori di tensione.")
            return voltageSensors
        }

        guard let voltageNamesUnmanaged = c_getVoltageSensorNames(voltageSensorsDict) else {
            print("Errore: c_getVoltageSensorNames ha restituito nil.")
            return voltageSensors
        }

        let voltageNamesCF = voltageNamesUnmanaged.takeRetainedValue() as CFArray

        guard let voltageNamesArray = voltageNamesCF as? [CFString] else {
            print("Errore: voltageNamesCF non è un array di CFString. Valore ricevuto: \(voltageNamesCF)")
            return voltageSensors
        }

        let voltageNames = voltageNamesArray as [String]

        guard let voltageValuesCF = c_getVoltageValues()?.takeRetainedValue() as? [NSNumber] else {
            print("Errore nel recuperare i valori dei sensori di tensione.")
            return voltageSensors
        }
        let voltageValues = voltageValuesCF as [NSNumber]

        let count = min(voltageNames.count, voltageValues.count)

        for i in 0..<count {
            let name = voltageNames[i]
            let value = voltageValues[i].doubleValue // Presunto in V

            voltageSensors.append(VoltageSensor(name: name, value: value))
        }

        return voltageSensors
    }

    func fetchHIDCurrentSensors() -> [CurrentSensor] {
        var currentSensors: [CurrentSensor] = []

        guard let currentSensorsDict = matching(0xff08, 2)?.takeRetainedValue() else {
            print("Errore nel recuperare i sensori di corrente.")
            return currentSensors
        }

        guard let currentNamesUnmanaged = c_getCurrentSensorNames(currentSensorsDict) else {
            print("Errore: c_getCurrentSensorNames ha restituito nil.")
            return currentSensors
        }

        let currentNamesCF = currentNamesUnmanaged.takeRetainedValue() as CFArray
        guard let currentNamesArray = currentNamesCF as? [CFString] else {
            print("Errore: currentNamesCF non è un array di CFString. Valore ricevuto: \(currentNamesCF)")
            return currentSensors
        }

        let currentNames = currentNamesArray as [String]

        guard let currentValuesUnmanaged = c_getCurrentValues() else {
            print("Errore: c_getCurrentValues ha restituito nil.")
            return currentSensors
        }

        let currentValuesCF = currentValuesUnmanaged.takeRetainedValue() as CFArray
        guard let currentValuesArray = currentValuesCF as? [NSNumber] else {
            print("Errore: currentValuesCF non è un array di NSNumber.")
            return currentSensors
        }

        let currentValues = currentValuesArray as [NSNumber]
        let count = min(currentNames.count, currentValues.count)

        for i in 0..<count {
            let name = currentNames[i]
            let value = currentValues[i].doubleValue // Presunto in A

            currentSensors.append(CurrentSensor(name: name, value: value))
        }

        return currentSensors
    }

    func fetchHIDTemperatureSensors() -> [TemperatureSensor] {
        var updatedTemperatureSensors: [TemperatureSensor] = []
        var pCoreValues: [Double] = []
        var eCoreValues: [Double] = []
        var socDieValues: [Double] = []
        var pmuTdevValues: [Double] = []
        var pmuTdieValues: [Double] = []
        var gpuValues: [Double] = []
        var batteryValue: Double?

        guard let thermalSensors = matching(0xff00, 5)?.takeRetainedValue() else {
            print("Errore nel recuperare i thermal sensors.")
            return updatedTemperatureSensors
        }

        guard let thermalSensorsDict = thermalSensors as? CFDictionary else {
            print("Errore: thermalSensors non è un CFDictionary.")
            return updatedTemperatureSensors
        }

        guard let sensorNamesUnmanaged = c_getTemperatureSensorNames(thermalSensorsDict) else {
            print("Errore: c_getTemperatureSensorNames ha restituito nil.")
            return updatedTemperatureSensors
        }

        let sensorNamesCF = sensorNamesUnmanaged.takeRetainedValue() as CFArray
        guard let sensorNamesArray = sensorNamesCF as? [CFString] else {
            print("Errore: sensorNamesCF non è un array di CFString. Valore ricevuto: \(sensorNamesCF)")
            return updatedTemperatureSensors
        }

        let sensorNames = sensorNamesArray as [String]

        guard let sensorValuesUnmanaged = c_getTemperatureValues() else {
            print("Errore: c_getTemperatureValues ha restituito nil.")
            return updatedTemperatureSensors
        }

        let sensorValuesCF = sensorValuesUnmanaged.takeRetainedValue() as CFArray
        guard let sensorValuesArray = sensorValuesCF as? [NSNumber] else {
            print("Errore: sensorValuesCF non è un array di NSNumber.")
            return updatedTemperatureSensors
        }

        let sensorValues = sensorValuesArray as [NSNumber]
        let count = min(sensorNames.count, sensorValues.count)

        for i in 0..<count {
            let name = sensorNames[i]
            let value = sensorValues[i].doubleValue

            if name.hasPrefix("pACC MTR Temp Sensor") {
                pCoreValues.append(value)
                updatedTemperatureSensors.append(TemperatureSensor(name: "P-Core \(pCoreValues.count)", value: value))
            } else if name.hasPrefix("eACC MTR Temp Sensor") {
                eCoreValues.append(value)
                updatedTemperatureSensors.append(TemperatureSensor(name: "E-Core \(eCoreValues.count)", value: value))
            } else if name.hasPrefix("PMGR SOC Die Temp Sensor") {
                socDieValues.append(value)
                updatedTemperatureSensors.append(TemperatureSensor(name: "SOC Die Temp \(socDieValues.count)", value: value))
            } else if name.hasPrefix("PMU tdev") {
                pmuTdevValues.append(value)
                updatedTemperatureSensors.append(TemperatureSensor(name: "PMU Device \(pmuTdevValues.count)", value: value))
            } else if name.hasPrefix("PMU tdie") {
                pmuTdieValues.append(value)
                updatedTemperatureSensors.append(TemperatureSensor(name: "PMU Die \(pmuTdieValues.count)", value: value))
            } else if name.hasPrefix("GPU MTR Temp Sensor") {
                gpuValues.append(value)
                updatedTemperatureSensors.append(TemperatureSensor(name: "GPU \(gpuValues.count)", value: value))
            } else if name == "gas gauge battery" {
                batteryValue = value
                updatedTemperatureSensors.append(TemperatureSensor(name: "Battery", value: value))
            }
        }

        if !pCoreValues.isEmpty {
            let pCoreAverage = pCoreValues.reduce(0, +) / Double(pCoreValues.count)
            updatedTemperatureSensors.append(TemperatureSensor(name: "P-Cores (AVG)", value: pCoreAverage))
        }

        if !eCoreValues.isEmpty {
            let eCoreAverage = eCoreValues.reduce(0, +) / Double(eCoreValues.count)
            updatedTemperatureSensors.append(TemperatureSensor(name: "E-Cores (AVG)", value: eCoreAverage))
        }

        if !socDieValues.isEmpty {
            let socDieAverage = socDieValues.reduce(0, +) / Double(socDieValues.count)
            updatedTemperatureSensors.append(TemperatureSensor(name: "SOC Die Temp (AVG)", value: socDieAverage))
        }

        if !pmuTdevValues.isEmpty {
            let pmuTdevAverage = pmuTdevValues.reduce(0, +) / Double(pmuTdevValues.count)
            updatedTemperatureSensors.append(TemperatureSensor(name: "PMU Device (AVG)", value: pmuTdevAverage))
        }

        if !pmuTdieValues.isEmpty {
            let pmuTdieAverage = pmuTdieValues.reduce(0, +) / Double(pmuTdieValues.count)
            updatedTemperatureSensors.append(TemperatureSensor(name: "PMU Die (AVG)", value: pmuTdieAverage))
        }

        if !gpuValues.isEmpty {
            let gpuAverage = gpuValues.reduce(0, +) / Double(gpuValues.count)
            updatedTemperatureSensors.append(TemperatureSensor(name: "GPU", value: gpuAverage))
        }

        return updatedTemperatureSensors
    }

    func updateHIDSensors() async {
        // Fetching dei sensori in background
        async let newTemperatureSensors = fetchHIDTemperatureSensors()
        var newCurrentSensors: [CurrentSensor] = []
        var newVoltageSensors: [VoltageSensor] = []

        if overlaySettings.showUnknownSensors {
            async let fetchedCurrentSensors = fetchHIDCurrentSensors()
            async let fetchedVoltageSensors = fetchHIDVoltageSensorData()
            newCurrentSensors = await fetchedCurrentSensors
            newVoltageSensors = await fetchedVoltageSensors
        }

        let temperatureSensors = await newTemperatureSensors
        let currentSensors = newCurrentSensors
        let voltageSensors = newVoltageSensors

        // Aggiornamento dei sensori sul Main Thread
        DispatchQueue.main.async {
            self.updateSensorValues(existingSensors: &self.hidSensors.temperatureSensors, newSensors: temperatureSensors)

            if self.overlaySettings.showUnknownSensors {
                self.updateSensorValues(existingSensors: &self.hidSensors.currentSensors, newSensors: currentSensors)
                self.updateSensorValues(existingSensors: &self.hidSensors.voltageSensors, newSensors: voltageSensors)
            } else {
                self.hidSensors.currentSensors.removeAll()
                self.hidSensors.voltageSensors.removeAll()
            }
        }
    }

    func fetchAdditionalSensors() {
        // Implementazione se necessario...
    }

    func clearAdditionalSensors() {
        DispatchQueue.main.async {
            self.hidSensors.voltageSensors.removeAll()
            self.hidSensors.currentSensors.removeAll()
        }
    }

    private func updateSensorValues<T: SensorProtocol & Equatable>(existingSensors: inout [T], newSensors: [T]) {
        for newSensor in newSensors {
            if let index = existingSensors.firstIndex(where: { $0.name == newSensor.name }) {
                existingSensors[index].value = newSensor.value // Aggiorna il valore esistente
            } else {
                existingSensors.append(newSensor) // Aggiungi nuovo sensore
            }
        }

        // Disattiva i sensori non più presenti
        for i in 0..<existingSensors.count {
            if !newSensors.contains(where: { $0.name == existingSensors[i].name }) {
                existingSensors[i].isActive = false
            }
        }
    }

    // MARK: - Timer Management
    func startHIDUpdateTimer() {
        hidUpdateTimer = Timer.scheduledTimer(withTimeInterval: 2.0, repeats: true) { [weak self] _ in
            Task {
                await self?.updateHIDSensors()
            }
        }
    }

    func stopHIDUpdateTimer() {
        hidUpdateTimer?.invalidate()
        hidUpdateTimer = nil
    }
}
