//File Protocol

import Combine
import Foundation
import SwiftUI

enum SensorKind: String {
    case temperature
    case voltage
    case current
    case power
    case frequency
    case usage
    case memory
    case fan
    // Aggiungi altre tipologie se necessario
}



class AnySensor: ObservableObject, Identifiable {
    @Published var id: UUID
    @Published var name: String
    @Published var customDisplayName: String
    @Published var value: Double
    @Published var isActive: Bool
    @Published var nameColor: Color
    @Published var valueColor: Color
    @Published var font: Font
    @Published var displayValue: String
    @Published var showName: Bool = true
    @Published var useCustomName: Bool = false
    @Published var sensorKind: SensorKind

    private var cancellable: AnyCancellable?
    let sensor: any SensorProtocol // Make `sensor` accessible

    init<SensorType: SensorProtocol>(_ sensor: SensorType) {
        self.sensor = sensor
        self.id = sensor.id
        self.name = sensor.name
        self.customDisplayName = sensor.customDisplayName
        self.value = sensor.value
        self.isActive = sensor.isActive
        self.nameColor = sensor.nameColor
        self.valueColor = sensor.valueColor
        self.font = sensor.font
        self.displayValue = sensor.displayValue
        self.sensorKind = sensor.sensorKind

        cancellable = sensor.objectWillChange.sink { [weak self] _ in
            guard let self = self else { return }
            self.id = sensor.id
            self.name = sensor.name
            self.value = sensor.value
            self.displayValue = sensor.displayValue
            self.sensorKind = sensor.sensorKind
            self.objectWillChange.send()
        }
    }
}





protocol SensorProtocol: Identifiable, ObservableObject {
    var id: UUID { get }
    var name: String { get set }
    var customDisplayName: String { get set }
    var value: Double { get set }
    var displayValue: String { get }
    var isActive: Bool { get set }
    var nameColor: Color { get set }
    var valueColor: Color { get set }
    var font: Font { get set }
    var sensorKind: SensorKind { get }
}


public class FanSensor: SensorProtocol, Equatable, ObservableObject {
    public let id = UUID()
    @Published var name: String
    @Published var customDisplayName: String
    @Published var value: Double
    @Published var isActive: Bool = false
    @Published var nameColor: Color = .primary
    @Published var valueColor: Color = .primary
    @Published var font: Font = .body
    var sensorKind: SensorKind {
        return .fan
        }
    var displayValue: String {
            return String(format: "%.0f RPM", value)
        }

    init(name: String, value: Double) {
        self.name = name
        self.customDisplayName = name
        self.value = value
    }

    public static func == (lhs: FanSensor, rhs: FanSensor) -> Bool {
        return lhs.name == rhs.name
    }
}

// VoltageSensor.swift
public class VoltageSensor: SensorProtocol, Equatable {
    public let id = UUID()
    @Published var name: String
    @Published var customDisplayName: String
    @Published var value: Double
    @Published var isActive: Bool = false
    @Published var nameColor: Color = .primary
    @Published var valueColor: Color = .primary
    @Published var font: Font = .body
    var sensorKind: SensorKind {
        return .voltage
        }
    var displayValue: String {
            return String(format: "%.2f V", value)
        }

    init(name: String, value: Double) {
        self.name = name
        self.customDisplayName = name
        self.value = value
    }

    public static func == (lhs: VoltageSensor, rhs: VoltageSensor) -> Bool {
        return lhs.name == rhs.name
    }
}

// CurrentSensor.swift
public class CurrentSensor: SensorProtocol, Equatable {
    public let id = UUID()
    @Published var name: String
    @Published var customDisplayName: String
    @Published var value: Double
    @Published var isActive: Bool = false
    @Published var nameColor: Color = .primary
    @Published var valueColor: Color = .primary
    @Published var font: Font = .body
    var sensorKind: SensorKind {
        return .current
        }
    var displayValue: String {
            return String(format: "%.2f A", value)
        }

    init(name: String, value: Double) {
        self.name = name
        self.customDisplayName = name
        self.value = value
    }

    public static func == (lhs: CurrentSensor, rhs: CurrentSensor) -> Bool {
        return lhs.name == rhs.name
    }
}

// TemperatureSensor.swift
public class TemperatureSensor: SensorProtocol, Equatable {
    public let id = UUID()
    @Published var name: String
    @Published var customDisplayName: String
    @Published var value: Double
    @Published var isActive: Bool = false
    @Published var nameColor: Color = .primary
    @Published var valueColor: Color = .primary
    @Published var font: Font = .body
    var sensorKind: SensorKind {
        return .temperature
        }
    var displayValue: String {
            return String(format: "%.0f °C", value)
        }

    init(name: String, value: Double) {
        self.name = name
        self.customDisplayName = name
        self.value = value
    }

    public static func == (lhs: TemperatureSensor, rhs: TemperatureSensor) -> Bool {
        return lhs.name == rhs.name
    }
}

// PowerSensor.swift
public class PowerSensor: SensorProtocol, Equatable {
    public let id = UUID()
    @Published var name: String
    @Published var customDisplayName: String
    @Published var value: Double
    @Published var isActive: Bool = false
    @Published var nameColor: Color = .primary
    @Published var valueColor: Color = .primary
    @Published var font: Font = .body
    var sensorKind: SensorKind {
        return .power
        }
    var displayValue: String {
            return String(format: "%.2f W", value)
        }

    init(name: String, value: Double) {
        self.name = name
        self.customDisplayName = name
        self.value = value
    }

    public static func == (lhs: PowerSensor, rhs: PowerSensor) -> Bool {
        return lhs.name == rhs.name
    }
}

// FrequencySensor.swift
public class FrequencySensor: SensorProtocol, Equatable {
    public let id = UUID()
    @Published var name: String
    @Published var customDisplayName: String
    @Published var value: Double
    @Published var isActive: Bool = false
    @Published var nameColor: Color = .primary
    @Published var valueColor: Color = .primary
    @Published var font: Font = .body
    var sensorKind: SensorKind {
            return .frequency
        }
    var displayValue: String {
            return String(format: "%.0f MHz", value)
        }

    init(name: String, value: Double) {
        self.name = name
        self.customDisplayName = name
        self.value = value
    }

    public static func == (lhs: FrequencySensor, rhs: FrequencySensor) -> Bool {
        return lhs.name == rhs.name
    }
}

// UsageSensor.swift
public class UsageSensor: SensorProtocol, Equatable {
    public let id = UUID()
    @Published var name: String
    @Published var customDisplayName: String
    @Published var value: Double
    @Published var isActive: Bool = false
    @Published var nameColor: Color = .primary
    @Published var valueColor: Color = .primary
    @Published var font: Font = .body
    var sensorKind: SensorKind {
            return .usage
        }
    var displayValue: String {
            return String(format: "%.0f %%", value)
        }

    init(name: String, value: Double) {
        self.name = name
        self.customDisplayName = name
        self.value = value
    }

    public static func == (lhs: UsageSensor, rhs: UsageSensor) -> Bool {
        return lhs.name == rhs.name
    }
}
public enum CurrentUnit: String, CaseIterable {
    case mA = "mA"
    case A = "A"
}
