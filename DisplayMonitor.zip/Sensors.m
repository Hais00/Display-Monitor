// Nome del file: Sensors.m

#include <IOKit/hid/IOHIDLib.h>
#include <Foundation/Foundation.h>
#include <stdio.h>
#include <stdbool.h>
#include <pthread.h>

// Definizione delle strutture e dei tipi
typedef struct __IOHIDEvent *IOHIDEventRef;
typedef struct __IOHIDServiceClient *IOHIDServiceClientRef;
#ifdef __LP64__
typedef double IOHIDFloat;
#else
typedef float IOHIDFloat;
#endif

// Dichiarazioni delle funzioni IOKit
IOHIDEventSystemClientRef IOHIDEventSystemClientCreate(CFAllocatorRef allocator);
int IOHIDEventSystemClientSetMatching(IOHIDEventSystemClientRef client, CFDictionaryRef match);
IOHIDEventRef IOHIDServiceClientCopyEvent(IOHIDServiceClientRef, int64_t, int32_t, int64_t);
IOHIDFloat IOHIDEventGetFloatValue(IOHIDEventRef event, int32_t field);

// Definizione dei macro
#define IOHIDEventFieldBase(type)   (type << 16)
#define kIOHIDEventTypeTemperature  15
#define kIOHIDEventTypePower        25

// Struttura per la cache dei nomi dei sensori
typedef struct {
    IOHIDServiceClientRef serviceClient;
    CFStringRef sensorName;
} SensorNameCache;

// Parametri per la cache
#define MAX_SENSORS 256
static SensorNameCache sensorNameCache[MAX_SENSORS];
static int sensorNameCacheCount = 0;

// Definizione di CFStrings statiche per le chiavi
static CFStringRef kPrimaryUsagePageKey = NULL;
static CFStringRef kPrimaryUsageKey = NULL;

// Definizione di client HID statici
static IOHIDEventSystemClientRef temperatureSystem = NULL;
static IOHIDEventSystemClientRef currentSystem = NULL;
static IOHIDEventSystemClientRef voltageSystem = NULL;

// Mutex per la cache (opzionale, se il codice è multi-threaded)
static pthread_mutex_t cacheMutex = PTHREAD_MUTEX_INITIALIZER;

// Inizializzazione delle CFStrings statiche e dei client HID
__attribute__((constructor))
static void initialize_matching_keys_and_hid_clients() {
    kPrimaryUsagePageKey = CFStringCreateWithCString(NULL, "PrimaryUsagePage", kCFStringEncodingUTF8);
    kPrimaryUsageKey = CFStringCreateWithCString(NULL, "PrimaryUsage", kCFStringEncodingUTF8);

    temperatureSystem = IOHIDEventSystemClientCreate(kCFAllocatorDefault);
    currentSystem = IOHIDEventSystemClientCreate(kCFAllocatorDefault);
    voltageSystem = IOHIDEventSystemClientCreate(kCFAllocatorDefault);
}

// Funzione di supporto per creare i criteri di ricerca per i sensori
CFDictionaryRef matching(int page, int usage) {
    CFNumberRef nums[2];
    CFStringRef keys[2];

    keys[0] = kPrimaryUsagePageKey;
    keys[1] = kPrimaryUsageKey;
    nums[0] = CFNumberCreate(NULL, kCFNumberSInt32Type, &page);
    nums[1] = CFNumberCreate(NULL, kCFNumberSInt32Type, &usage);

    CFDictionaryRef dict = CFDictionaryCreate(NULL, (const void **)keys, (const void **)nums, 2,
                                              &kCFTypeDictionaryKeyCallBacks, &kCFTypeDictionaryValueCallBacks);

    // Rilascia le CFNumbers dopo averle aggiunte al dizionario
    CFRelease(nums[0]);
    CFRelease(nums[1]);

    return dict;
}

// Funzione per cercare nella cache
bool findCachedName(IOHIDServiceClientRef sc, CFStringRef *outName) {
    bool found = false;
    pthread_mutex_lock(&cacheMutex);
    for (int i = 0; i < sensorNameCacheCount; i++) {
        if (sensorNameCache[i].serviceClient == sc) {
            *outName = sensorNameCache[i].sensorName;
            found = true;
            break;
        }
    }
    pthread_mutex_unlock(&cacheMutex);
    return found;
}

// Funzione per aggiungere alla cache
void addToCache(IOHIDServiceClientRef sc, CFStringRef name) {
    pthread_mutex_lock(&cacheMutex);
    if (sensorNameCacheCount < MAX_SENSORS) {
        sensorNameCache[sensorNameCacheCount].serviceClient = sc;
        sensorNameCache[sensorNameCacheCount].sensorName = CFRetain(name);
        sensorNameCacheCount++;
    }
    pthread_mutex_unlock(&cacheMutex);
}

// Funzione per ottenere i nomi dei sensori con caching
CFArrayRef c_getSensorNames(CFDictionaryRef sensors, IOHIDEventSystemClientRef systemClient) {
    IOHIDEventSystemClientSetMatching(systemClient, sensors);
    CFArrayRef matchingsrvs = IOHIDEventSystemClientCopyServices(systemClient);

    long count = CFArrayGetCount(matchingsrvs);
    CFMutableArrayRef array = CFArrayCreateMutable(kCFAllocatorDefault, count, &kCFTypeArrayCallBacks);

    for (long i = 0; i < count; i++) {
        IOHIDServiceClientRef sc = (IOHIDServiceClientRef)CFArrayGetValueAtIndex(matchingsrvs, i);
        CFStringRef name = NULL;

        if (findCachedName(sc, &name)) {
            CFArrayAppendValue(array, name);
        } else {
            // Recupera il nome dal servizio HID
            name = IOHIDServiceClientCopyProperty(sc, CFSTR("Product"));
            if (!name) {
                name = CFSTR("noname");
            }

            // Aggiungi alla cache se c'è spazio
            if (name != CFSTR("noname")) {
                addToCache(sc, name);
            }

            CFArrayAppendValue(array, name);

            // Rilascia il nome se non è "noname"
            if (name != CFSTR("noname")) {
                CFRelease(name);
            }
        }
    }

    CFRelease(matchingsrvs);
    return array;
}

// Funzione per ottenere i nomi dei sensori di temperatura
CFArrayRef c_getTemperatureSensorNames(CFDictionaryRef sensors) {
    return c_getSensorNames(sensors, temperatureSystem);
}

// Funzione per ottenere i nomi dei sensori di tensione
CFArrayRef c_getVoltageSensorNames(CFDictionaryRef sensors) {
    return c_getSensorNames(sensors, voltageSystem);
}

// Funzione per ottenere i nomi dei sensori di corrente
CFArrayRef c_getCurrentSensorNames(CFDictionaryRef sensors) {
    return c_getSensorNames(sensors, currentSystem);
}

// Funzione generica ottimizzata per ottenere i valori dei sensori
CFArrayRef c_getSensorValues(int usagePage, int usage, IOHIDElementType eventType, IOHIDEventSystemClientRef systemClient) {
    CFDictionaryRef sensors = matching(usagePage, usage);
    IOHIDEventSystemClientSetMatching(systemClient, sensors);
    CFRelease(sensors);

    CFArrayRef matchingsrvs = IOHIDEventSystemClientCopyServices(systemClient);
    long count = CFArrayGetCount(matchingsrvs);
    CFMutableArrayRef array = CFArrayCreateMutable(kCFAllocatorDefault, count, &kCFTypeArrayCallBacks);

    for (long i = 0; i < count; i++) {
        IOHIDServiceClientRef sc = (IOHIDServiceClientRef)CFArrayGetValueAtIndex(matchingsrvs, i);
        IOHIDEventRef event = IOHIDServiceClientCopyEvent(sc, eventType, 0, 0);

        CFNumberRef value = NULL;
        if (event) {
            double sensorValue = IOHIDEventGetFloatValue(event, IOHIDEventFieldBase(eventType));
            value = CFNumberCreate(kCFAllocatorDefault, kCFNumberDoubleType, &sensorValue);
            CFRelease(event);
        } else {
            double sensorValue = 0.0;
            value = CFNumberCreate(kCFAllocatorDefault, kCFNumberDoubleType, &sensorValue);
        }

        CFArrayAppendValue(array, value);
        CFRelease(value);
    }

    CFRelease(matchingsrvs);
    return array;
}

// Funzione per ottenere i valori di temperatura
CFArrayRef c_getTemperatureValues(void) {
    return c_getSensorValues(0xff00, 5, kIOHIDEventTypeTemperature, temperatureSystem);
}

// Funzione per ottenere i valori di corrente
CFArrayRef c_getCurrentValues(void) {
    return c_getSensorValues(0xff08, 2, kIOHIDEventTypePower, currentSystem);
}

// Funzione per ottenere i valori di tensione
CFArrayRef c_getVoltageValues(void) {
    return c_getSensorValues(0xff08, 3, kIOHIDEventTypePower, voltageSystem);
}

// Funzione per ottenere gli FPS correnti
int getCurrentFPS(void) {
    // Implementa la logica per ottenere gli FPS, se necessario
    return 0; // Placeholder
}

// Funzione di setup chiamata all'iniezione della libreria
void setup(void) {
    // Implementa l'inizializzazione dell'hook su glSwapBuffers, se necessario
}
