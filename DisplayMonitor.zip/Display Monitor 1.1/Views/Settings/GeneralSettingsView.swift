import SwiftUI
import HotKey

struct GeneralSettingsView: View {
    @EnvironmentObject var overlaySettings: OverlaySettings
    
    @State private var overlayShortcutInput: String = ""
    @State private var sensorsShortcutInput: String = ""
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Toggle("Show Unknown Sensors", isOn: $overlaySettings.showUnknownSensors)
                .padding()
            
            // Configurazione scorciatoia per Overlay
            VStack(alignment: .leading) {
                HStack(spacing: 4) {
                    Text("Overlay Shortcut")
                        .font(.headline)
                    Spacer()
                    HStack(spacing: 2) {
                        Text("⌘") // simbolo per Command
                            .font(.system(size: 16, weight: .bold))
                        Text("⇧") // simbolo per Shift
                            .font(.system(size: 16, weight: .bold))
                        Text("+")
                        TextField("Key (e.g., O, S)", text: $overlayShortcutInput, onCommit: {
                            if let firstChar = overlayShortcutInput.uppercased().first {
                                overlaySettings.overlayShortcut = String(firstChar)
                            }
                        })
                        .frame(width: 30)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                    }
                }
                .onAppear {
                    overlayShortcutInput = overlaySettings.overlayShortcut
                }
            }
            .padding()
            
        }
    }
}

// Estensione per convertire caratteri in Key di HotKey
extension Key {
    init?(character: Character) {
        switch character {
        case "A": self = .a
        case "B": self = .b
        case "C": self = .c
        case "D": self = .d
        case "E": self = .e
        case "F": self = .f
        case "G": self = .g
        case "H": self = .h
        case "I": self = .i
        case "J": self = .j
        case "K": self = .k
        case "L": self = .l
        case "M": self = .m
        case "N": self = .n
        case "O": self = .o
        case "P": self = .p
        case "Q": self = .q
        case "R": self = .r
        case "S": self = .s
        case "T": self = .t
        case "U": self = .u
        case "V": self = .v
        case "W": self = .w
        case "X": self = .x
        case "Y": self = .y
        case "Z": self = .z
        case "1": self = .one
        case "2": self = .two
        case "3": self = .three
        case "4": self = .four
        case "5": self = .five
        case "6": self = .six
        case "7": self = .seven
        case "8": self = .eight
        case "9": self = .nine
        case "0": self = .zero
        default: return nil
        }
    }
}
