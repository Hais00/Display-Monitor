// PowermetricsController.swift
import SwiftUI
import Combine

class PowermetricsController {
    var powermetricsSensors: PowermetricsSensors
    var powermetricsProcess: Process?
    var userPassword: String?

    private var cancellables = Set<AnyCancellable>()

    init(powermetricsSensors: PowermetricsSensors, userPassword: String?) {
        self.powermetricsSensors = powermetricsSensors
        self.userPassword = userPassword
    }

    func startPowermetrics() {
        // Arresta eventuali processi powermetrics attivi prima di iniziarne uno nuovo
        stopPowermetrics()

        // Verifica che la password dell'utente sia stata memorizzata
        guard let password = userPassword else {
            print("Errore: password dell'utente non impostata.")
            return
        }

        // Avvia il processo powermetrics in background
        DispatchQueue.global(qos: .background).async { [weak self] in
            guard let self = self else { return }

            // Configura il processo powermetrics con il comando necessario
            let process = Process()
            process.launchPath = "/bin/bash"
            process.arguments = ["-c", "echo '\(password)' | sudo -S /usr/bin/powermetrics --samplers cpu_power,gpu_power -i 2000"]

            // Imposta una pipe per catturare l'output in tempo reale
            let pipe = Pipe()
            process.standardOutput = pipe
            process.standardError = pipe

            // Memorizza il processo powermetrics
            self.powermetricsProcess = process

            // Avvia il processo e gestisce eventuali errori durante l'esecuzione
            do {
                try process.run()
                print("Powermetrics avviato con successo.")

                // Inizia a leggere l'output dalla pipe
                self.readDataFromPipe(pipe)
            } catch {
                print("Errore durante l'avvio di powermetrics: \(error)")
            }
        }
    }

    func stopPowermetrics() {
        if let process = powermetricsProcess, process.isRunning {
            process.terminate()
            powermetricsProcess = nil
            print("Powermetrics terminato.")
        }
    }

    func readDataFromPipe(_ pipe: Pipe) {
        // Imposta un handler per leggere i dati dalla pipe riga per riga
        pipe.fileHandleForReading.readabilityHandler = { [weak self] fileHandle in
            guard let self = self else { return }
            
            // Legge i dati dalla pipe
            let data = fileHandle.availableData
            if let output = String(data: data, encoding: .utf8) {
                // Parsea l'output ricevuto
                self.parsePowermetrics(output: output)
            }
        }
    }

    // MARK: - Parsing dei Dati di Powermetrics
    func parsePowermetrics(output: String) {
        let lines = output.split(separator: "\n").map { String($0) }

        var frequencyDataTemp = [String: FrequencySensor]()
        var usageDataTemp = [String: UsageSensor]()
        var powerDataTemp = [String: PowerSensor]()

        var eCoreCPUs: [Int] = []
        var pCoreCPUs: [Int] = []
        var cpuNumberToCoreType: [Int: String] = [:]

        var currentCluster: String? = nil
        var eCoreIndex = 0
        var pCoreIndex = 0

        for line in lines {
            let trimmedLine = line.trimmingCharacters(in: .whitespaces)
            if trimmedLine.isEmpty {
                continue
            }

            // Identifica l'inizio di un cluster e aggiorna `currentCluster`
            if trimmedLine.starts(with: "E-Cluster") {
                currentCluster = "E-Cluster"
            } else if trimmedLine.starts(with: "P-Cluster") {
                currentCluster = "P-Cluster"
            }

            // Rimuovi l'aggiunta dei dati aggregati dei cluster
            if let cluster = currentCluster {
                if trimmedLine.starts(with: "\(cluster) HW active frequency:") ||
                   trimmedLine.starts(with: "\(cluster) HW active residency:") ||
                   trimmedLine.starts(with: "\(cluster) idle residency:") {
                    // Salta l'elaborazione dei dati aggregati dei cluster
                    continue
                }
            }

            // Gestione delle linee dei core individuali
            if trimmedLine.starts(with: "CPU ") && trimmedLine.range(of: #"CPU \d"#, options: .regularExpression) != nil {
                // Estrai il numero della CPU
                let cpuComponents = trimmedLine.components(separatedBy: " ")
                if cpuComponents.count >= 2, let cpuNumber = Int(cpuComponents[1]) {
                    // Assegna il core al cluster corrente
                    if let cluster = currentCluster {
                        cpuNumberToCoreType[cpuNumber] = cluster
                        if cluster == "E-Cluster" {
                            if !eCoreCPUs.contains(cpuNumber) {
                                eCoreCPUs.append(cpuNumber)
                            }
                        } else if cluster == "P-Cluster" {
                            if !pCoreCPUs.contains(cpuNumber) {
                                pCoreCPUs.append(cpuNumber)
                            }
                        }
                    }
                }

                // Parsing delle proprietà del core
                let components = trimmedLine.components(separatedBy: ":")
                if components.count > 1 {
                    let key = components[0]
                    let valuePart = components[1].trimmingCharacters(in: .whitespaces)

                    if let cpuNumber = Int(key.components(separatedBy: " ")[1]),
                       let cluster = cpuNumberToCoreType[cpuNumber] {

                        // Determina il nome del core basato sul cluster
                        let coreType: String
                        if cluster == "E-Cluster" {
                            if let index = eCoreCPUs.firstIndex(of: cpuNumber) {
                                coreType = "E-Core \(index)"
                            } else {
                                coreType = "E-Core \(eCoreIndex)"
                                eCoreIndex += 1
                            }
                        } else if cluster == "P-Cluster" {
                            if let index = pCoreCPUs.firstIndex(of: cpuNumber) {
                                coreType = "P-Core \(index)"
                            } else {
                                coreType = "P-Core \(pCoreIndex)"
                                pCoreIndex += 1
                            }
                        } else {
                            coreType = "CPU \(cpuNumber)"
                        }

                        if key.hasSuffix("frequency") {
                            if let frequencyStr = valuePart.components(separatedBy: " ").first,
                               let frequency = Double(frequencyStr) {
                                frequencyDataTemp[coreType] = FrequencySensor(name: "\(coreType)", value: frequency)
                            }
                        } else if key.hasSuffix("active residency") {
                            if let usagePercentage = valuePart.components(separatedBy: "%").first,
                               let usage = Double(usagePercentage) {
                                usageDataTemp[coreType] = UsageSensor(name: "\(coreType)", value: usage)
                            }
                        } else if key.hasSuffix("idle residency") {
                            if let idlePercentage = valuePart.components(separatedBy: "%").first,
                               let idleUsage = Double(idlePercentage) {
                                let identifier = "\(coreType) Idle"
                                usageDataTemp[identifier] = UsageSensor(name: "\(identifier)", value: idleUsage)
                            }
                        }
                    }
                }
                continue
            }

            // Gestione di altre chiavi (Power, GPU, ecc.)
            let components = trimmedLine.components(separatedBy: ":")
            if components.count > 1 {
                let key = components[0]
                let valuePart = components[1].trimmingCharacters(in: .whitespaces)

                if key.hasSuffix("Power") {
                    let component = key.replacingOccurrences(of: " Power", with: "")
                    let powerStr = valuePart.replacingOccurrences(of: " mW", with: "").trimmingCharacters(in: .whitespaces)
                    if let powerValue = Double(powerStr) {
                        powerDataTemp[component] = PowerSensor(name: "\(component)", value: powerValue / 1000.0) // Converti in W
                    }
                } else if key.hasSuffix("HW active frequency") {
                    let component = key.replacingOccurrences(of: " HW active frequency", with: "")
                    if let frequencyStr = valuePart.components(separatedBy: " ").first,
                       let frequency = Double(frequencyStr) {
                        frequencyDataTemp[component] = FrequencySensor(name: "\(component)", value: frequency)
                    }
                } else if key.hasSuffix("HW active residency") {
                    let component = key.replacingOccurrences(of: " HW active residency", with: "")
                    if let usagePercentage = valuePart.components(separatedBy: "%").first,
                       let usage = Double(usagePercentage) {
                        usageDataTemp[component] = UsageSensor(name: "\(component)", value: usage)
                    }
                } else if key.hasSuffix("idle residency") && !key.starts(with: "CPU ") {
                    let component = key.replacingOccurrences(of: " idle residency", with: "")
                    if let idlePercentage = valuePart.components(separatedBy: "%").first,
                       let idleUsage = Double(idlePercentage) {
                        usageDataTemp["\(component) Idle"] = UsageSensor(name: "\(component) Idle", value: idleUsage)
                    }
                }
            }
        }

        // Calcolo della media di utilizzo per P-cores ed E-cores (NON IDLE)
        // Calcolo per P-cores
        if !pCoreCPUs.isEmpty {
            var pCoreUsageSum: Double = 0.0
            var pCoreCount: Int = 0
            for cpuNumber in pCoreCPUs {
                // Determina l'indice del core
                if let index = pCoreCPUs.firstIndex(of: cpuNumber) {
                    let coreType = "P-Core \(index)"
                    if let usage = usageDataTemp[coreType]?.value {
                        pCoreUsageSum += usage
                        pCoreCount += 1
                    }
                }
            }
            if pCoreCount > 0 {
                let pCoreAverage = pCoreUsageSum / Double(pCoreCount)
                usageDataTemp["P-Cores Average"] = UsageSensor(name: "P-Cores Average", value: pCoreAverage)
            }
        }

        // Calcolo per E-cores
        if !eCoreCPUs.isEmpty {
            var eCoreUsageSum: Double = 0.0
            var eCoreCount: Int = 0
            for cpuNumber in eCoreCPUs {
                // Determina l'indice del core
                if let index = eCoreCPUs.firstIndex(of: cpuNumber) {
                    let coreType = "E-Core \(index)"
                    if let usage = usageDataTemp[coreType]?.value {
                        eCoreUsageSum += usage
                        eCoreCount += 1
                    }
                }
            }
            if eCoreCount > 0 {
                let eCoreAverage = eCoreUsageSum / Double(eCoreCount)
                usageDataTemp["E-Cores Average"] = UsageSensor(name: "E-Cores Average", value: eCoreAverage)
            }
        }

        // **Calcolo delle frequenze medie per P-cores ed E-cores**
        // Calcolo per P-cores
        if !pCoreCPUs.isEmpty {
            var pCoreFrequencySum: Double = 0.0
            var pCoreFrequencyCount: Int = 0
            for cpuNumber in pCoreCPUs {
                if let index = pCoreCPUs.firstIndex(of: cpuNumber) {
                    let coreType = "P-Core \(index)"
                    if let frequency = frequencyDataTemp[coreType]?.value {
                        pCoreFrequencySum += frequency
                        pCoreFrequencyCount += 1
                    }
                }
            }
            if pCoreFrequencyCount > 0 {
                let pCoreFrequencyAverage = pCoreFrequencySum / Double(pCoreFrequencyCount)
                frequencyDataTemp["P-Cores Frequency Average"] = FrequencySensor(name: "P-Cores Frequency Average", value: pCoreFrequencyAverage)
            }
        }

        // Calcolo per E-cores
        if !eCoreCPUs.isEmpty {
            var eCoreFrequencySum: Double = 0.0
            var eCoreFrequencyCount: Int = 0
            for cpuNumber in eCoreCPUs {
                if let index = eCoreCPUs.firstIndex(of: cpuNumber) {
                    let coreType = "E-Core \(index)"
                    if let frequency = frequencyDataTemp[coreType]?.value {
                        eCoreFrequencySum += frequency
                        eCoreFrequencyCount += 1
                    }
                }
            }
            if eCoreFrequencyCount > 0 {
                let eCoreFrequencyAverage = eCoreFrequencySum / Double(eCoreFrequencyCount)
                frequencyDataTemp["E-Cores Frequency Average"] = FrequencySensor(name: "E-Cores Frequency Average", value: eCoreFrequencyAverage)
            }
        }

        // Aggiorna i dati dei sensori sul thread principale
        DispatchQueue.main.async {
            func updateSensors<T: SensorProtocol & Equatable>(existingSensors: inout [T], newSensorData: [String: T]) {
                for newSensor in newSensorData.values {
                    if let index = existingSensors.firstIndex(where: { $0.name == newSensor.name }) {
                        existingSensors[index].value = newSensor.value
                    } else {
                        existingSensors.append(newSensor)
                    }
                }
            }

            // Aggiorna i sensori di frequenza
            updateSensors(existingSensors: &self.powermetricsSensors.frequencyData, newSensorData: frequencyDataTemp)

            // Aggiorna i sensori di utilizzo
            updateSensors(existingSensors: &self.powermetricsSensors.usageData, newSensorData: usageDataTemp)

            // Aggiorna i sensori di potenza
            updateSensors(existingSensors: &self.powermetricsSensors.powerData, newSensorData: powerDataTemp)
        }
    }





    func getCurrentUsername() -> String? {
        return NSUserName()
    }
}
