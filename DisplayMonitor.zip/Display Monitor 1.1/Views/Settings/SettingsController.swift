import SwiftUI
import Cocoa

class SettingsWindowController: NSWindowController {
    init(overlaySettings: OverlaySettings) {
        // Crea la vista principale con una NavigationView che include SidebarView
        let contentView = NavigationView {
            SidebarView()
                .frame(minWidth: 200) // Imposta una larghezza minima per la sidebar
            GeneralSettingsView() // Vista di dettaglio predefinita
        }
        .environmentObject(overlaySettings) // Inietta l'EnvironmentObject

        // Configura la finestra
        let window = NSWindow(
            contentRect: NSRect(x: 0, y: 0, width: 600, height: 700),
            styleMask: [.titled, .closable, .miniaturizable, .resizable],
            backing: .buffered, defer: false
        )
        window.contentView = NSHostingView(rootView: contentView)
        window.title = "Settings"

        // Centra la finestra sullo schermo
        window.center()

        super.init(window: window)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
