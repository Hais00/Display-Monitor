import SwiftUI

struct SidebarView: View {
    var body: some View {
        List {
            NavigationLink(destination: GeneralSettingsView()) {
                Label("General", systemImage: "gearshape")
            }
            
            NavigationLink(destination: OverlaySettingsView()) {
                Label("Overlay", systemImage: "rectangle.stack.fill")
            }
        }
        .listStyle(SidebarListStyle()) // Imposta come stile di sidebar
        .navigationTitle("Settings")
    }
}
