import Foundation

public enum VoltageUnit: String, CaseIterable {
    case mV = "mV"
    case V = "V"
}
