import SwiftUI
import Combine

// Assicurati che SMCSensors e i tipi di sensori siano conformi a ObservableObject se necessario
// Altrimenti, aggiorna direttamente le proprietà in SMCController

class SMCController: ObservableObject {
    @Published var smcSensors: SMCSensors
    private var smcUpdateTimer: Timer?
    private let processingQueue = DispatchQueue(label: "SMCProcessingQueue", qos: .background)
    
    init(smcSensors: SMCSensors) {
        self.smcSensors = smcSensors
    }
    
    func SMCInitialize() {
        // Esegui l'elaborazione dei dati in background
        processingQueue.async { [weak self] in
            guard let self = self else { return }
            let smc = SMC.shared
            let sensorsByCategory = smc.getParsedSensors()
            
            // Aggiornamento delle proprietà @Published sul thread principale
            DispatchQueue.main.async {
                for (sensorType, sensors) in sensorsByCategory {
                    switch sensorType {
                    case .temperature:
                        for sensor in sensors {
                            guard let value = sensor.value else { continue }
                            if let index = self.smcSensors.temperatureSensors.firstIndex(where: { $0.name == sensor.name }) {
                                // Aggiorna il valore del sensore esistente
                                self.smcSensors.temperatureSensors[index].value = Double(Int(value))
                            } else {
                                // Aggiungi un nuovo sensore
                                let newSensor = TemperatureSensor(name: sensor.name, value: Double(Int(value)))
                                self.smcSensors.temperatureSensors.append(newSensor)
                            }
                        }
                    
                    case .voltage:
                        for sensor in sensors {
                            guard let value = sensor.value else { continue }
                            if let index = self.smcSensors.voltageSensors.firstIndex(where: { $0.name == sensor.name }) {
                                self.smcSensors.voltageSensors[index].value = value
                            } else {
                                let newSensor = VoltageSensor(name: sensor.name, value: value)
                                self.smcSensors.voltageSensors.append(newSensor)
                            }
                        }
                    
                    case .current:
                        for sensor in sensors {
                            guard let value = sensor.value else { continue }
                            if let index = self.smcSensors.currentSensors.firstIndex(where: { $0.name == sensor.name }) {
                                self.smcSensors.currentSensors[index].value = value
                            } else {
                                let newSensor = CurrentSensor(name: sensor.name, value: value)
                                self.smcSensors.currentSensors.append(newSensor)
                            }
                        }
                    
                    case .power:
                        for sensor in sensors {
                            guard let value = sensor.value else { continue }
                            if let index = self.smcSensors.powerSensors.firstIndex(where: { $0.name == sensor.name }) {
                                self.smcSensors.powerSensors[index].value = value
                            } else {
                                let newSensor = PowerSensor(name: sensor.name, value: value)
                                self.smcSensors.powerSensors.append(newSensor)
                            }
                        }
                    
                    case .fan:
                        for sensor in sensors {
                            let fanSpeed = sensor.value ?? 0.0
                            if let index = self.smcSensors.fanSensors.firstIndex(where: { $0.name == sensor.name }) {
                                self.smcSensors.fanSensors[index].value = fanSpeed
                            } else {
                                let newSensor = FanSensor(name: sensor.name, value: fanSpeed)
                                self.smcSensors.fanSensors.append(newSensor)
                            }
                        }
                    }
                }
            }
        }
    }
    
    // Funzione per avviare il timer
    func startSMCUpdateTimer() {
        smcUpdateTimer = Timer.scheduledTimer(withTimeInterval: 2.0, repeats: true) { [weak self] _ in
            self?.SMCInitialize()
        }
    }
    
    // Funzione per fermare il timer (da chiamare alla chiusura dell'app)
    func stopSMCUpdateTimer() {
        smcUpdateTimer?.invalidate()
        smcUpdateTimer = nil
    }
    
    // Funzione di aggiornamento dei sensori SMC che chiama SMCInitialize
    func updateSMCSensors() {
        SMCInitialize()
    }
    
    deinit {
        stopSMCUpdateTimer()
    }
    
    // Se necessario, puoi aggiungere ulteriori funzioni di supporto qui
}
