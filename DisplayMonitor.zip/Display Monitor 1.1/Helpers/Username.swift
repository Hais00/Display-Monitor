import Foundation

func getCurrentUsername() -> String? {
    let process = Process()
    process.launchPath = "/usr/bin/whoami"
    
    let pipe = Pipe()
    process.standardOutput = pipe
    
    do {
        try process.run()
        process.waitUntilExit()
        
        let data = pipe.fileHandleForReading.readDataToEndOfFile()
        let username = String(data: data, encoding: .utf8)?.trimmingCharacters(in: .whitespacesAndNewlines)
        return username
    } catch {
        // print("Error retrieving current username: \(error)") // Debug print commentato
        return nil
    }
}
