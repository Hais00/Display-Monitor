import SwiftUI


final class PowermetricsSensors: ObservableObject {
    @Published var frequencyData: [FrequencySensor] = []
    @Published var powerData: [PowerSensor] = []
    @Published var usageData: [UsageSensor] = []
}
