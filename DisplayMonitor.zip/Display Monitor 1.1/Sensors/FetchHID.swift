import SwiftUI

public final class HIDSensors: ObservableObject {
    @Published var temperatureSensors: [TemperatureSensor] = []
    @Published var voltageSensors: [VoltageSensor] = []
    @Published var currentSensors: [CurrentSensor] = []
    @Published var powerSensors: [PowerSensor] = []

    @Published var selectedVoltageUnit: VoltageUnit = .mV
    @Published var selectedCurrentUnit: CurrentUnit = .mA

    // Metodo per iniziare il fetching dei sensori sconosciuti
    func fetchAdditionalSensors() {
        // Attiva i sensori di tensione e corrente
        // Potrebbe essere necessario notificare il controller di iniziare il fetching
    }

    // Metodo per interrompere il fetching e pulire i sensori sconosciuti
    func clearAdditionalSensors() {
        DispatchQueue.main.async {
            self.voltageSensors.removeAll()
            self.currentSensors.removeAll()
        }
    }
}

